<?php

require_once __DIR__ . '/basedatos.php';
require_once __DIR__ . '/sesion.php';

function obtenerTituloModulo($rol) {
    $sql = "SELECT titulo FROM perfil WHERE rol = ? LIMIT 1";
    $resultado = ejecutarConsultaPreparada($sql, "s", [$rol]);
    
    if ($resultado && $fila = $resultado->fetch_assoc()) {
        return $fila['titulo'];
    }
    
    return 'TopVending';
}

function obtenerOpcionesMenu($rol, $modulo) {
    $sql = "SELECT orden, boton, enlace 
            FROM menu 
            WHERE rol = ? AND modulo = ? 
            ORDER BY orden ASC";
    
    $resultado = ejecutarConsultaPreparada($sql, "ss", [$rol, $modulo]);
    
    $opciones = [];
    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $opciones[] = $fila;
        }
    }
    
    return $opciones;
}

function generarMenuHTML($rol, $modulo) {
    $datosSesion = obtenerDatosSesion();
    $usuario = $datosSesion['usuario'];
    $titulo = obtenerTituloModulo($rol);
    $opciones = obtenerOpcionesMenu($rol, $modulo);
    
    $html = '<header class="menu-principal">';
    $html .= '<div class="menu-header">';
    $html .= '<h1 class="menu-titulo">' . htmlspecialchars($titulo) . '</h1>';
    $html .= '</div>';
    
    $html .= '<nav class="menu-nav">';
    $html .= '<ul class="menu-opciones">';
    
    foreach ($opciones as $opcion) {
        $boton = htmlspecialchars($opcion['boton']);
        $enlace = htmlspecialchars($opcion['enlace']);
        
        $paginaActual = $_SERVER['PHP_SELF'];
        $claseActiva = (strpos($paginaActual, $enlace) !== false) ? 'activa' : '';
        
        $html .= '<li class="menu-item ' . $claseActiva . '">';
        $html .= '<a href="' . $enlace . '" class="menu-link">' . $boton . '</a>';
        $html .= '</li>';
    }
    
    $html .= '</ul></nav>';
    
    $html .= '<div class="menu-usuario">';
    $html .= '<span class="usuario-nombre">👤 ' . htmlspecialchars($usuario) . '</span>';
    $html .= '<span class="usuario-rol">(' . htmlspecialchars($rol) . ')</span>';
    $html .= '<a href="/topvending/logout.php" class="btn-logout">Salir</a>';
    $html .= '</div>';
    
    $html .= '</header>';
    
    return $html;
}

function mostrarMenu() {
    if (!verificarSesion()) {
        return;
    }
    
    $datosSesion = obtenerDatosSesion();
    echo generarMenuHTML($datosSesion['rol'], $datosSesion['modulo']);
}
?>