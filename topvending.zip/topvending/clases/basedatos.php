<?php
/**
 * Archivo: /topvending/clases/basedatos.php
 * Propósito: Gestionar la conexión a la base de datos MySQL
 * Uso: Include este archivo cuando necesites acceso a BD
 */

// Parámetros de conexión a la base de datos
// IMPORTANTE: Modificar estos valores según tu entorno
define('DB_HOST', 'localhost');      // Dirección del servidor MySQL
define('DB_USER', 'root');           // Usuario de MySQL
define('DB_PASS', '');               // Contraseña (vacía en XAMPP por defecto)
define('DB_NAME', 'topvending');     // Nombre de la base de datos

// Variable global para la conexión
$conexion = null;

/**
 * Función: conectarBD()
 * Propósito: Establecer conexión con MySQL usando mysqli
 * Retorna: objeto mysqli o termina el script si hay error
 */
function conectarBD() {
    // Accede a la variable global $conexion
    global $conexion;
    
    // Si ya existe una conexión, la reutiliza (patrón singleton)
    if ($conexion !== null) {
        return $conexion;
    }
    
    // Intenta crear la conexión
    $conexion = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Verifica si hubo error en la conexión
    if ($conexion->connect_error) {
        // Registra el error y termina la ejecución
        error_log("Error de conexión BD: " . $conexion->connect_error);
        die("Error de conexión a la base de datos. Contacte al administrador.");
    }
    
    // Establece el charset a UTF-8 para evitar problemas con acentos
    $conexion->set_charset("utf8");
    
    return $conexion;
}

/**
 * Función: cerrarBD()
 * Propósito: Cerrar la conexión a la base de datos
 * Buena práctica: Llamar al final de scripts largos
 */
function cerrarBD() {
    global $conexion;
    
    if ($conexion !== null) {
        $conexion->close();
        $conexion = null;
    }
}

/**
 * Función: ejecutarConsulta($sql)
 * Propósito: Ejecutar una consulta SQL y retornar el resultado
 * Parámetros: $sql - Cadena con la consulta SQL
 * Retorna: Resultado de la consulta o false si hay error
 */
function ejecutarConsulta($sql) {
    $conn = conectarBD();
    $resultado = $conn->query($sql);
    
    if (!$resultado) {
        // Registra el error SQL
        error_log("Error SQL: " . $conn->error . " | Consulta: " . $sql);
    }
    
    return $resultado;
}

/**
 * Función: ejecutarConsultaPreparada($sql, $tipos, $valores)
 * Propósito: Ejecutar consultas preparadas (más seguras contra SQL Injection)
 * Parámetros: 
 *   $sql - Consulta con ? como placeholders
 *   $tipos - String con tipos de datos (i=integer, d=double, s=string, b=blob)
 *   $valores - Array con los valores a vincular
 * Retorna: Resultado de la consulta o false
 * 
 * Ejemplo de uso:
 *   $sql = "SELECT * FROM usuarios WHERE user = ? AND pass = ?";
 *   $resultado = ejecutarConsultaPreparada($sql, "ss", ["admin", "password123"]);
 */
function ejecutarConsultaPreparada($sql, $tipos, $valores) {
    $conn = conectarBD();
    
    // Prepara la consulta
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        error_log("Error preparando consulta: " . $conn->error);
        return false;
    }
    
    // Vincula los parámetros
    // El operador ... desempaqueta el array $valores
    $stmt->bind_param($tipos, ...$valores);
    
    // Ejecuta la consulta
    $stmt->execute();
    
    // Obtiene el resultado
    $resultado = $stmt->get_result();
    
    return $resultado;
}

// Conexión automática al incluir el archivo
// Esto asegura que siempre haya conexión disponible
conectarBD();
?>