<?php
/**
 * Archivo: /topvending/clases/log.php
 * Propósito: Registrar eventos del sistema en BD y archivo
 * Uso: Include donde necesites registrar eventos
 */

require_once __DIR__ . '/basedatos.php';

/**
 * Función: registrarLog()
 * Propósito: Registra un evento en la tabla log de la BD
 * 
 * Parámetros:
 *   $categoria - 'ERROR', 'WARNING' o 'INFO'
 *   $idempleado - ID del empleado (null si es evento del sistema)
 *   $rol - Rol del usuario (null si no aplica)
 *   $idmaquina - ID de la máquina (null si no aplica)
 *   $idincidencia - ID de incidencia (null si no aplica)
 *   $idproducto - ID del producto (null si no aplica)
 *   $uds - Unidades (null si no aplica)
 *   $descripcion - Descripción del evento
 * 
 * Retorna: true si se registró correctamente, false si hubo error
 * 
 * Ejemplo de uso:
 *   registrarLog('INFO', 3, 'SUMINISTROS', 4, null, 5, 10, 'Reposición de producto');
 */
function registrarLog($categoria, $idempleado, $rol, $idmaquina, 
                      $idincidencia, $idproducto, $uds, $descripcion) {
    
    // Valida que la categoría sea correcta
    $categoriasValidas = ['ERROR', 'WARNING', 'INFO'];
    if (!in_array($categoria, $categoriasValidas)) {
        $categoria = 'INFO'; // Valor por defecto
    }
    
    // Prepara la consulta SQL
    // Usamos consulta preparada para seguridad
    $sql = "INSERT INTO log (categoria, idempleado, rol, idmaquina, 
                             idincidencia, idproducto, uds, fechareg, descripcion) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
    
    try {
        $conn = conectarBD();
        $stmt = $conn->prepare($sql);
        
        // bind_param() vincula las variables a los ? de la consulta
        // Tipos: s=string, i=integer
        // Los valores NULL se pasan directamente
        $stmt->bind_param("sisiiiis", 
            $categoria,      // s = string
            $idempleado,     // i = integer (puede ser NULL)
            $rol,            // s = string (puede ser NULL)
            $idmaquina,      // i = integer (puede ser NULL)
            $idincidencia,   // i = integer (puede ser NULL)
            $idproducto,     // i = integer (puede ser NULL)
            $uds,            // i = integer (puede ser NULL)
            $descripcion     // s = string
        );
        
        // Ejecuta la consulta
        $resultado = $stmt->execute();
        
        // Cierra el statement
        $stmt->close();
        
        // También registra en archivo de texto para backup
        registrarLogArchivo($categoria, $descripcion);
        
        return $resultado;
        
    } catch (Exception $e) {
        // Si falla la BD, al menos intenta escribir en archivo
        error_log("Error al registrar log en BD: " . $e->getMessage());
        registrarLogArchivo('ERROR', 'Fallo al registrar en BD: ' . $descripcion);
        return false;
    }
}

/**
 * Función: registrarLogArchivo($categoria, $mensaje)
 * Propósito: Escribe eventos en archivo de texto como backup
 * 
 * El archivo se guarda en /topvending/log/log.txt
 * Formato: [FECHA HORA] [CATEGORIA] Mensaje
 */
function registrarLogArchivo($categoria, $mensaje) {
    // Define la ruta del archivo de log
    $archivoLog = __DIR__ . '/../log/log.txt';
    
    // Crea el directorio si no existe
    $dirLog = dirname($archivoLog);
    if (!file_exists($dirLog)) {
        mkdir($dirLog, 0777, true); // Crea directorios recursivamente
    }
    
    // Formato del mensaje: [2025-12-11 10:30:45] [INFO] Descripción del evento
    $fecha = date('Y-m-d H:i:s');
    $linea = "[$fecha] [$categoria] $mensaje" . PHP_EOL;
    
    // file_put_contents con FILE_APPEND añade al final sin borrar contenido previo
    // LOCK_EX evita que dos procesos escriban simultáneamente
    file_put_contents($archivoLog, $linea, FILE_APPEND | LOCK_EX);
}

/**
 * Función: obtenerLogs($limite, $categoria, $fechaDesde, $fechaHasta)
 * Propósito: Consulta logs de la base de datos con filtros
 * 
 * Parámetros:
 *   $limite - Número máximo de registros (null = todos)
 *   $categoria - Filtro por categoría (null = todas)
 *   $fechaDesde - Fecha inicial (null = sin filtro)
 *   $fechaHasta - Fecha final (null = sin filtro)
 * 
 * Retorna: Array de registros de log
 * 
 * Ejemplo de uso:
 *   $logs = obtenerLogs(50, 'ERROR', '2025-12-01', null);
 */
function obtenerLogs($limite = 100, $categoria = null, 
                     $fechaDesde = null, $fechaHasta = null) {
    
    // Construye la consulta base usando la vista log_chachi
    $sql = "SELECT * FROM log_chachi WHERE 1=1";
    
    // Array para almacenar los parámetros de la consulta preparada
    $parametros = [];
    $tipos = "";
    
    // Añade filtro por categoría si se especifica
    if ($categoria !== null) {
        $sql .= " AND Tipo = ?";
        $tipos .= "s";
        $parametros[] = $categoria;
    }
    
    // Añade filtro por fecha desde
    if ($fechaDesde !== null) {
        $sql .= " AND Fecha >= ?";
        $tipos .= "s";
        $parametros[] = $fechaDesde;
    }
    
    // Añade filtro por fecha hasta
    if ($fechaHasta !== null) {
        $sql .= " AND Fecha <= ?";
        $tipos .= "s";
        $parametros[] = $fechaHasta . " 23:59:59";
    }
    
    // Ordena por fecha descendente (más recientes primero)
    $sql .= " ORDER BY Fecha DESC";
    
    // Añade límite si se especifica
    if ($limite !== null) {
        $sql .= " LIMIT ?";
        $tipos .= "i";
        $parametros[] = $limite;
    }
    
    // Ejecuta la consulta
    if (count($parametros) > 0) {
        $resultado = ejecutarConsultaPreparada($sql, $tipos, $parametros);
    } else {
        $resultado = ejecutarConsulta($sql);
    }
    
    // Convierte el resultado en array
    $logs = [];
    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $logs[] = $fila;
        }
    }
    
    return $logs;
}

/**
 * Función: limpiarLogsAntiguos($dias)
 * Propósito: Elimina logs más antiguos que X días
 * Uso: Ejecutar periódicamente para no sobrecargar la BD
 * 
 * Parámetros: $dias - Número de días a mantener (default: 90)
 * 
 * Ejemplo de uso (en tarea programada):
 *   limpiarLogsAntiguos(30); // Mantiene solo últimos 30 días
 */
function limpiarLogsAntiguos($dias = 90) {
    $sql = "DELETE FROM log WHERE fechareg < DATE_SUB(NOW(), INTERVAL ? DAY)";
    
    $conn = conectarBD();
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $dias);
    $resultado = $stmt->execute();
    
    $filasEliminadas = $stmt->affected_rows;
    $stmt->close();
    
    if ($resultado) {
        registrarLog('INFO', null, 'SISTEMA', null, null, null, null, 
                     "Limpieza de logs: $filasEliminadas registros eliminados");
    }
    
    return $filasEliminadas;
}
?>