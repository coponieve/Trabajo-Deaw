<?php
/**
 * Archivo: /topvending/clases/config.php
 * ACTUALIZADO para nueva estructura de BD
 */

// Paginación
define('REGISTROS_POR_PAGINA', 10);
define('MAX_REGISTROS_LOG', 50);

// Rutas
define('RUTA_LOG', __DIR__ . '/../log/log.txt');

// Formato
define('FORMATO_FECHA', 'd/m/Y H:i:s');

// Estados de máquina (según tabla estado)
define('ESTADOS_MAQUINA', ['Averiada', 'En Servicio', 'Desactivada']);

// IMPORTANTE: Nueva BD usa tabla 'modelo' separada
// Ya no son strings, ahora son IDs
define('MODELOS_MAQUINA', [
    1 => 'STAR24',  // 4x6 = 24 productos
    2 => 'STAR30',  // 5x6 = 30 productos
    3 => 'STAR42'   // 7x6 = 42 productos
]);

// Categorías de productos
define('CATEGORIAS_PRODUCTO', [
    'REFRESCOS',
    'DULCES',
    'FRUTOS SECOS',
    'BEBIDAS CALIENTES'
]);

// Categorías de log
define('CATEGORIAS_LOG', ['INFO', 'WARNING', 'ERROR']);

function obtenerConfig($clave) {
    return defined($clave) ? constant($clave) : null;
}
?>