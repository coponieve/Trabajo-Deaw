<?php
/**
 * CORREGIDO: Evita bucles de redirección
 */

function iniciarSesion() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
        
        if (!isset($_SESSION['ultima_regeneracion'])) {
            $_SESSION['ultima_regeneracion'] = time();
        } else if (time() - $_SESSION['ultima_regeneracion'] > 300) {
            session_regenerate_id(true);
            $_SESSION['ultima_regeneracion'] = time();
        }
    }
}

function verificarSesion() {
    iniciarSesion();
    
    return isset($_SESSION['usuario']) && 
           isset($_SESSION['idempleado']) && 
           isset($_SESSION['rol']);
}

function requiereSesion() {
    // CRÍTICO: Evita bucle si ya estamos en login.php
    $paginaActual = basename($_SERVER['PHP_SELF']);
    if ($paginaActual === 'login.php') {
        return; // No redirige si ya está en login
    }
    
    if (!verificarSesion()) {
        $_SESSION['url_destino'] = $_SERVER['REQUEST_URI'];
        
        // Ruta ABSOLUTA
        header("Location: /topvending/login.php");
        exit();
    }
}

function verificarRol($rolesPermitidos) {
    if (!verificarSesion()) {
        return false;
    }
    
    return in_array($_SESSION['rol'], $rolesPermitidos);
}

function crearSesion($usuario, $idempleado, $rol, $modulo) {
    iniciarSesion();
    
    session_regenerate_id(true);
    
    $_SESSION['usuario'] = $usuario;
    $_SESSION['idempleado'] = $idempleado;
    $_SESSION['rol'] = $rol;
    $_SESSION['modulo'] = $modulo;
    $_SESSION['ultima_actividad'] = time();
    $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
    
    require_once 'log.php';
    registrarLog('INFO', $idempleado, $rol, null, null, null, null, 
                 "Login exitoso desde IP: " . $_SESSION['ip']);
}

function cerrarSesion() {
    iniciarSesion();
    
    if (isset($_SESSION['idempleado'])) {
        require_once 'log.php';
        registrarLog('INFO', $_SESSION['idempleado'], $_SESSION['rol'], 
                     null, null, null, null, "Logout");
    }
    
    $_SESSION = array();
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    
    session_destroy();
}

function obtenerDatosSesion() {
    if (!verificarSesion()) {
        return null;
    }
    
    return [
        'usuario' => $_SESSION['usuario'],
        'idempleado' => $_SESSION['idempleado'],
        'rol' => $_SESSION['rol'],
        'modulo' => $_SESSION['modulo']
    ];
}

function verificarTimeout($minutos = 30) {
    iniciarSesion();
    
    if (isset($_SESSION['ultima_actividad'])) {
        $tiempoInactivo = time() - $_SESSION['ultima_actividad'];
        $tiempoMaximo = $minutos * 60;
        
        if ($tiempoInactivo > $tiempoMaximo) {
            cerrarSesion();
            header("Location: /topvending/login.php?timeout=1");
            exit();
        }
    }
    
    $_SESSION['ultima_actividad'] = time();
}

iniciarSesion();
?>