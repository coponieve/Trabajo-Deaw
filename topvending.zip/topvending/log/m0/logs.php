<?php
/**
 * Archivo: /topvending/m0/logs.php
 * Propósito: Visualización de logs con filtros y scroll vertical
 * Funcionalidad: 
 *   - Lista con scroll vertical
 *   - Filtro por categoría (INFO, WARNING, ERROR)
 *   - Filtro por número de serie de máquina
 *   - Filtros combinados
 *   - Ordenado por fecha descendente
 *   - Limitado por configuración (MAX_REGISTROS_LOG)
 */

// ========== SECCIÓN 1: INCLUDES Y SEGURIDAD ==========
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/menu.php';
require_once __DIR__ . '/../clases/config.php';

requiereSesion();
verificarTimeout(30);

if (!verificarRol(['ADMIN'])) {
    die('Acceso denegado. Este módulo es solo para administradores.');
}

// ========== SECCIÓN 2: PROCESAMIENTO DE FILTROS ==========

// Obtiene los filtros aplicados
$filtroCategoria = isset($_GET['categoria']) ? trim($_GET['categoria']) : '';
$filtroNumSerie = isset($_GET['numserie']) ? trim($_GET['numserie']) : '';

// ========== SECCIÓN 3: CONSTRUCCIÓN DE CONSULTA CON FILTROS ==========

// Consulta base usando la vista log_chachi
$sql = "SELECT * FROM log_chachi WHERE 1=1";

// Array para almacenar parámetros de consulta preparada
$parametros = [];
$tipos = "";

// Aplica filtro por categoría si está seleccionado
if (!empty($filtroCategoria) && $filtroCategoria !== 'TODOS') {
    $sql .= " AND Tipo = ?";
    $tipos .= "s";
    $parametros[] = $filtroCategoria;
}

// Aplica filtro por número de serie si está seleccionado
if (!empty($filtroNumSerie) && $filtroNumSerie !== 'TODOS') {
    $sql .= " AND NSerie = ?";
    $tipos .= "s";
    $parametros[] = $filtroNumSerie;
}

// Ordena por fecha descendente (más recientes primero)
$sql .= " ORDER BY Fecha DESC";

// Aplica límite de registros según configuración
$limite = MAX_REGISTROS_LOG;
$sql .= " LIMIT ?";
$tipos .= "i";
$parametros[] = $limite;

// Ejecuta la consulta
if (count($parametros) > 0) {
    $conn = conectarBD();
    $stmt = $conn->prepare($sql);
    
    // bind_param requiere referencias, usamos ... (spread operator)
    $stmt->bind_param($tipos, ...$parametros);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $stmt->close();
} else {
    // Si no hay parámetros, ejecuta consulta directa
    $resultado = ejecutarConsulta($sql);
}

// Convierte resultado a array para poder contar y recorrer
$logs = [];
if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) {
        $logs[] = $fila;
    }
}

// ========== SECCIÓN 4: OBTENCIÓN DE DATOS PARA FILTROS ==========

// Obtiene categorías únicas de la tabla log
$sqlCategorias = "SELECT DISTINCT categoria FROM log ORDER BY categoria";
$resultadoCat = ejecutarConsulta($sqlCategorias);
$categorias = [];
if ($resultadoCat) {
    while ($fila = $resultadoCat->fetch_assoc()) {
        $categorias[] = $fila['categoria'];
    }
}

// Obtiene números de serie únicos de máquinas
$sqlNumSerie = "SELECT DISTINCT m.numserie FROM log l
                INNER JOIN maquina m ON l.idmaquina = m.idmaquina
                ORDER BY m.numserie";
$resultadoSerie = ejecutarConsulta($sqlNumSerie);
$numsSerie = [];
if ($resultadoSerie) {
    while ($fila = $resultadoSerie->fetch_assoc()) {
        $numsSerie[] = $fila['numserie'];
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Registro de Logs</title>
    <link rel="stylesheet" href="/topvending/css/estilos.css">
    <style>
        .container { max-width: 1600px; margin: 0 auto; padding: 20px; }
        .page-header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; 
                      box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        
        /* Panel de filtros */
        .filters-panel { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; 
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .filters-grid { display: grid; grid-template-columns: 1fr 1fr auto; gap: 15px; align-items: end; }
        .filter-group label { display: block; margin-bottom: 8px; color: #666; font-size: 14px; font-weight: 500; }
        .filter-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; 
                              background: white; cursor: pointer; }
        
        /* Información de resultados */
        .results-info { background: #f9fafb; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; 
                       display: flex; justify-content: space-between; align-items: center; }
        .results-count { font-weight: 600; color: #333; }
        .filters-active { color: #667eea; font-size: 14px; }
        
        /* Contenedor de logs con scroll */
        .logs-container { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
                         overflow: hidden; }
        .logs-scroll { max-height: 600px; overflow-y: auto; }
        
        /* Tabla de logs */
        table { width: 100%; border-collapse: collapse; }
        thead { background: #f9fafb; position: sticky; top: 0; z-index: 10; }
        th { padding: 12px 15px; text-align: left; font-size: 12px; font-weight: 600; 
             color: #666; text-transform: uppercase; border-bottom: 2px solid #e5e7eb; }
        td { padding: 12px 15px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
        tbody tr:hover { background: #f9fafb; }
        
        /* Categorías con colores */
        .cat-info { background: #dbeafe; color: #1e40af; padding: 4px 10px; border-radius: 12px; 
                    font-size: 11px; font-weight: 600; display: inline-block; }
        .cat-warning { background: #fef3c7; color: #92400e; padding: 4px 10px; border-radius: 12px; 
                      font-size: 11px; font-weight: 600; display: inline-block; }
        .cat-error { background: #fee2e2; color: #991b1b; padding: 4px 10px; border-radius: 12px; 
                    font-size: 11px; font-weight: 600; display: inline-block; }
        
        /* Columna de fecha más estrecha */
        .col-fecha { width: 180px; white-space: nowrap; font-family: monospace; color: #666; }
        .col-tipo { width: 100px; }
        .col-empleado { width: 200px; }
        .col-maquina { width: 120px; }
        .col-descripcion { max-width: 400px; }
        
        /* Botones de acción */
        .actions-bar { display: flex; gap: 10px; justify-content: space-between; align-items: center; 
                      margin-bottom: 20px; }
        .btn-generar { display: inline-flex; align-items: center; gap: 8px; }
        
        /* Estado vacío */
        .empty-state { text-align: center; padding: 60px 20px; color: #999; }
        .empty-state h3 { font-size: 20px; margin-bottom: 10px; }
        
        /* Scroll personalizado */
        .logs-scroll::-webkit-scrollbar { width: 10px; }
        .logs-scroll::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 5px; }
        .logs-scroll::-webkit-scrollbar-thumb { background: #888; border-radius: 5px; }
        .logs-scroll::-webkit-scrollbar-thumb:hover { background: #555; }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📋 Registro de Logs del Sistema</h1>
            <p>Visualización y filtrado de eventos del sistema TopVending</p>
        </div>
        
        <!-- Barra de acciones -->
        <div class="actions-bar">
            <div>
                <button onclick="generarLog('INFO')" class="btn btn-primary btn-generar">
                    ℹ️ Generar Log INFO
                </button>
                <button onclick="generarLog('WARNING')" class="btn btn-warning btn-generar">
                    ⚠️ Generar Log WARNING
                </button>
                <button onclick="generarLog('ERROR')" class="btn btn-danger btn-generar">
                    ❌ Generar Log ERROR
                </button>
            </div>
            <button onclick="location.reload()" class="btn btn-secondary">
                🔄 Actualizar
            </button>
        </div>
        
        <!-- Panel de filtros -->
        <div class="filters-panel">
            <h3 style="margin: 0 0 20px 0; color: #333;">🔍 Filtros de Búsqueda</h3>
            
            <form method="GET" action="">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label>Categoría</label>
                        <select name="categoria" class="form-control">
                            <option value="TODOS" <?php echo ($filtroCategoria === '' || $filtroCategoria === 'TODOS') ? 'selected' : ''; ?>>
                                Todas las categorías
                            </option>
                            <?php foreach ($categorias as $cat): ?>
                            <option value="<?php echo $cat; ?>" <?php echo ($filtroCategoria === $cat) ? 'selected' : ''; ?>>
                                <?php echo $cat; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Número de Serie</label>
                        <select name="numserie" class="form-control">
                            <option value="TODOS" <?php echo ($filtroNumSerie === '' || $filtroNumSerie === 'TODOS') ? 'selected' : ''; ?>>
                                Todas las máquinas
                            </option>
                            <?php foreach ($numsSerie as $ns): ?>
                            <option value="<?php echo $ns; ?>" <?php echo ($filtroNumSerie === $ns) ? 'selected' : ''; ?>>
                                <?php echo $ns; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="height: 44px;">
                        Aplicar Filtros
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Información de resultados -->
        <div class="results-info">
            <div>
                <span class="results-count"><?php echo count($logs); ?> registro(s) encontrado(s)</span>
                <span style="color: #999; margin-left: 10px;">
                    (Máximo: <?php echo MAX_REGISTROS_LOG; ?> registros)
                </span>
            </div>
            <div class="filters-active">
                <?php if (!empty($filtroCategoria) && $filtroCategoria !== 'TODOS'): ?>
                    <span>📌 Categoría: <?php echo $filtroCategoria; ?></span>
                <?php endif; ?>
                <?php if (!empty($filtroNumSerie) && $filtroNumSerie !== 'TODOS'): ?>
                    <span style="margin-left: 15px;">📌 Máquina: <?php echo $filtroNumSerie; ?></span>
                <?php endif; ?>
                <?php if ((empty($filtroCategoria) || $filtroCategoria === 'TODOS') && 
                         (empty($filtroNumSerie) || $filtroNumSerie === 'TODOS')): ?>
                    <span>Sin filtros activos</span>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Contenedor de logs -->
        <div class="logs-container">
            <div class="logs-scroll">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th class="col-fecha">Fecha y Hora</th>
                            <th class="col-tipo">Tipo</th>
                            <th class="col-empleado">Empleado</th>
                            <th>Usuario</th>
                            <th>Módulo</th>
                            <th class="col-maquina">Nº Serie</th>
                            <th>Producto</th>
                            <th>Uds</th>
                            <th class="col-descripcion">Descripción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($logs) > 0): ?>
                            <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><?php echo $log['id']; ?></td>
                                <td class="col-fecha">
                                    <?php 
                                    // Formatea la fecha
                                    $fecha = new DateTime($log['Fecha']);
                                    echo $fecha->format('d/m/Y H:i:s');
                                    ?>
                                </td>
                                <td class="col-tipo">
                                    <?php 
                                    $claseCat = 'cat-info';
                                    if ($log['Tipo'] === 'WARNING') $claseCat = 'cat-warning';
                                    if ($log['Tipo'] === 'ERROR') $claseCat = 'cat-error';
                                    ?>
                                    <span class="<?php echo $claseCat; ?>">
                                        <?php echo $log['Tipo']; ?>
                                    </span>
                                </td>
                                <td class="col-empleado">
                                    <?php echo $log['Empleado'] ? htmlspecialchars($log['Empleado']) : '<em style="color:#999;">Sistema</em>'; ?>
                                </td>
                                <td><?php echo $log['user'] ? htmlspecialchars($log['user']) : '-'; ?></td>
                                <td><?php echo $log['Modulo'] ? htmlspecialchars($log['Modulo']) : '-'; ?></td>
                                <td class="col-maquina">
                                    <?php echo $log['NSerie'] ? htmlspecialchars($log['NSerie']) : '-'; ?>
                                </td>
                                <td><?php echo $log['Producto'] ? htmlspecialchars($log['Producto']) : '-'; ?></td>
                                <td><?php echo $log['Unidades'] !== null ? $log['Unidades'] : '-'; ?></td>
                                <td class="col-descripcion">
                                    <?php echo htmlspecialchars($log['Descripion']); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10">
                                    <div class="empty-state">
                                        <h3>😕 No se encontraron registros</h3>
                                        <p>Intenta cambiar los filtros o genera nuevos logs</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        /**
         * Función: generarLog(categoria)
         * Propósito: Llama al script genera_log.php para crear un nuevo log
         * Parámetros: categoria - 'INFO', 'WARNING' o 'ERROR'
         */
        function generarLog(categoria) {
            // Muestra mensaje de carga
            const btn = event.target;
            const textoOriginal = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '⏳ Generando...';
            
            // Llama al generador de logs
            fetch('/topvending/m0/genera_log.php?categoria=' + categoria)
                .then(response => response.json())
                .then(data => {
                    if (data.exito) {
                        alert('✅ Log generado correctamente:\n\n' + data.descripcion);
                        // Recarga la página para mostrar el nuevo log
                        location.reload();
                    } else {
                        alert('❌ Error: ' + (data.error || 'Error desconocido'));
                        btn.disabled = false;
                        btn.innerHTML = textoOriginal;
                    }
                })
                .catch(error => {
                    alert('❌ Error de red: ' + error);
                    btn.disabled = false;
                    btn.innerHTML = textoOriginal;
                });
        }
    </script>
</body>
</html>