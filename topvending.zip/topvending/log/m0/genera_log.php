<?php
/**
 * Archivo: /topvending/m0/genera_log.php
 * Propósito: Proceso en background para generar entradas de log con valores aleatorios
 * Uso: Se invoca con parámetro "categoria" (INFO, WARNING, ERROR)
 * 
 * Ejemplos de uso:
 *   genera_log.php?categoria=INFO
 *   genera_log.php?categoria=WARNING
 *   genera_log.php?categoria=ERROR
 */

require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/log.php';
require_once __DIR__ . '/../clases/config.php';

// ========== FUNCIÓN PRINCIPAL ==========

/**
 * Función: generarLogAleatorio($categoria)
 * Propósito: Genera una entrada de log con datos aleatorios de la BD
 * 
 * Parámetros:
 *   $categoria - 'INFO', 'WARNING' o 'ERROR'
 * 
 * Lógica:
 *   1. Selecciona empleado aleatorio
 *   2. Selecciona máquina aleatoria
 *   3. Selecciona producto aleatorio
 *   4. Genera descripción según la categoría
 *   5. Inserta en tabla log
 */
function generarLogAleatorio($categoria) {
    // Valida la categoría
    if (!in_array($categoria, CATEGORIAS_LOG)) {
        return ['error' => 'Categoría inválida. Debe ser INFO, WARNING o ERROR'];
    }
    
    // ========== OBTENCIÓN DE DATOS ALEATORIOS ==========
    
    // Obtiene empleado aleatorio
    $sqlEmpleado = "SELECT idempleado, categoria FROM empleado 
                    WHERE estadolaboral = 'activo' 
                    ORDER BY RAND() LIMIT 1";
    $resultadoEmp = ejecutarConsulta($sqlEmpleado);
    $empleado = $resultadoEmp ? $resultadoEmp->fetch_assoc() : null;
    
    // Obtiene máquina aleatoria
    $sqlMaquina = "SELECT idmaquina, numserie FROM maquina 
                   ORDER BY RAND() LIMIT 1";
    $resultadoMaq = ejecutarConsulta($sqlMaquina);
    $maquina = $resultadoMaq ? $resultadoMaq->fetch_assoc() : null;
    
    // Obtiene producto aleatorio
    $sqlProducto = "SELECT idproducto, marca, modelo FROM producto 
                    ORDER BY RAND() LIMIT 1";
    $resultadoProd = ejecutarConsulta($sqlProducto);
    $producto = $resultadoProd ? $resultadoProd->fetch_assoc() : null;
    
    // ========== GENERACIÓN DE DESCRIPCIÓN SEGÚN CATEGORÍA ==========
    
    $descripciones = [];
    
    // Descripciones para INFO
    if ($categoria === 'INFO') {
        $descripciones = [
            "Reposición de producto: {$producto['marca']} {$producto['modelo']}",
            "Inicio de sesión exitoso",
            "Consulta de estado de máquina {$maquina['numserie']}",
            "Actualización de stock completada",
            "Sincronización con central exitosa",
            "Mantenimiento preventivo realizado",
            "Backup de datos completado",
            "Máquina {$maquina['numserie']} asignada a cliente"
        ];
    }
    
    // Descripciones para WARNING
    elseif ($categoria === 'WARNING') {
        $udsRestantes = rand(1, 5);
        $descripciones = [
            "Stock bajo: {$producto['marca']} {$producto['modelo']} ({$udsRestantes} uds)",
            "Alcanzado umbral de reposición en máquina {$maquina['numserie']}",
            "Intento de acceso con credenciales incorrectas",
            "Tiempo de respuesta elevado en máquina {$maquina['numserie']}",
            "Temperatura fuera de rango en máquina {$maquina['numserie']}",
            "Producto próximo a caducar: {$producto['marca']} {$producto['modelo']}",
            "Detectado consumo inusual en máquina {$maquina['numserie']}"
        ];
    }
    
    // Descripciones para ERROR
    elseif ($categoria === 'ERROR') {
        $descripciones = [
            "Máquina {$maquina['numserie']} averiada",
            "Producto {$producto['marca']} {$producto['modelo']} agotado",
            "Fallo en sistema de pago de máquina {$maquina['numserie']}",
            "Pérdida de conexión con central - Máquina {$maquina['numserie']}",
            "Error en dispensador de máquina {$maquina['numserie']}",
            "Fallo en sensor de temperatura",
            "Error crítico en sistema de cambio",
            "Atasco detectado en máquina {$maquina['numserie']}"
        ];
    }
    
    // Selecciona una descripción aleatoria
    $descripcion = $descripciones[array_rand($descripciones)];
    
    // ========== GENERACIÓN DE UNIDADES ALEATORIAS ==========
    
    // Solo genera unidades para categoría INFO (representa ventas/reposiciones)
    $uds = null;
    if ($categoria === 'INFO' && rand(0, 1) == 1) {
        // 50% de probabilidad de incluir unidades
        $uds = rand(1, 15);
    }
    
    // ========== REGISTRO EN BASE DE DATOS ==========
    
    $idempleado = $empleado ? $empleado['idempleado'] : null;
    $rol = $empleado ? $empleado['categoria'] : null;
    $idmaquina = $maquina ? $maquina['idmaquina'] : null;
    $idproducto = $producto ? $producto['idproducto'] : null;
    
    // Llama a la función registrarLog
    $resultado = registrarLog(
        $categoria,
        $idempleado,
        $rol,
        $idmaquina,
        null,  // idincidencia (no se genera en este proceso)
        $idproducto,
        $uds,
        $descripcion
    );
    
    if ($resultado) {
        return [
            'exito' => true,
            'categoria' => $categoria,
            'descripcion' => $descripcion,
            'empleado' => $empleado ? $empleado['idempleado'] : 'Sistema',
            'maquina' => $maquina ? $maquina['numserie'] : 'N/A',
            'producto' => $producto ? "{$producto['marca']} {$producto['modelo']}" : 'N/A',
            'unidades' => $uds
        ];
    } else {
        return ['error' => 'Error al registrar el log en la base de datos'];
    }
}

// ========== PROCESAMIENTO DE LA SOLICITUD ==========

// Obtiene la categoría del parámetro GET
$categoria = isset($_GET['categoria']) ? strtoupper(trim($_GET['categoria'])) : null;

// Si no se proporciona categoría, muestra instrucciones
if (!$categoria) {
    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'Debe especificar una categoría',
        'uso' => 'genera_log.php?categoria=INFO|WARNING|ERROR',
        'ejemplos' => [
            'INFO' => 'genera_log.php?categoria=INFO',
            'WARNING' => 'genera_log.php?categoria=WARNING',
            'ERROR' => 'genera_log.php?categoria=ERROR'
        ]
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Genera el log
$resultado = generarLogAleatorio($categoria);

// Retorna resultado en formato JSON
header('Content-Type: application/json');
echo json_encode($resultado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

/**
 * ========== EJEMPLOS DE USO ==========
 * 
 * 1. Generar log INFO desde navegador:
 *    http://localhost/topvending/m0/genera_log.php?categoria=INFO
 * 
 * 2. Generar log WARNING:
 *    http://localhost/topvending/m0/genera_log.php?categoria=WARNING
 * 
 * 3. Generar log ERROR:
 *    http://localhost/topvending/m0/genera_log.php?categoria=ERROR
 * 
 * 4. Desde JavaScript (AJAX):
 *    fetch('/topvending/m0/genera_log.php?categoria=INFO')
 *      .then(response => response.json())
 *      .then(data => console.log(data));
 * 
 * 5. Desde PHP (otro script):
 *    $resultado = file_get_contents('http://localhost/topvending/m0/genera_log.php?categoria=INFO');
 *    $data = json_decode($resultado, true);
 * 
 * 6. Tarea programada (Linux cron):
 *    # Genera log INFO cada 5 minutos
 *    *5 * * * * curl http://localhost/topvending/m0/genera_log.php?categoria=INFO
 * 
 *    # Genera logs aleatorios cada hora
 *    0 * * * * php /var/www/html/topvending/m0/genera_log.php categoria=INFO
 *    15 * * * * php /var/www/html/topvending/m0/genera_log.php categoria=WARNING
 *    30 * * * * php /var/www/html/topvending/m0/genera_log.php categoria=ERROR
 * 
 * 7. Tarea programada (Windows):
 *    Programa: php.exe
 *    Argumentos: C:\xampp\htdocs\topvending\m0\genera_log.php categoria=INFO
 *    Repetir: Cada 5 minutos
 */
?>