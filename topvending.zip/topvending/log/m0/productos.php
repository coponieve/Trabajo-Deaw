<?php
/**
 * Archivo: /topvending/m0/productos.php
 * Propósito: CRUD completo de productos con paginación
 * Funcionalidad: Listar, Crear, Editar y Eliminar productos
 */

// ========== SECCIÓN 1: INCLUDES Y SEGURIDAD ==========
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/log.php';
require_once __DIR__ . '/../clases/menu.php';
require_once __DIR__ . '/../clases/config.php';

requiereSesion();
verificarTimeout(30);

if (!verificarRol(['ADMIN'])) {
    die('Acceso denegado. Este módulo es solo para administradores.');
}

// ========== SECCIÓN 2: PROCESAMIENTO DE ACCIONES ==========

$mensaje = '';
$tipoMensaje = '';

// Procesar ELIMINAR
if (isset($_GET['accion']) && $_GET['accion'] === 'eliminar' && isset($_GET['id'])) {
    $idEliminar = (int)$_GET['id'];
    
    // Verifica si el producto está siendo usado en alguna máquina
    $sqlVerificar = "SELECT COUNT(*) as total FROM maquinaproducto WHERE idproducto = ?";
    $resultadoVerif = ejecutarConsultaPreparada($sqlVerificar, "i", [$idEliminar]);
    $filaVerif = $resultadoVerif->fetch_assoc();
    
    if ($filaVerif['total'] > 0) {
        $mensaje = "No se puede eliminar el producto porque está asignado a {$filaVerif['total']} máquina(s)";
        $tipoMensaje = 'warning';
    } else {
        // Obtiene info del producto antes de eliminar
        $sqlInfo = "SELECT marca, modelo FROM producto WHERE idproducto = ?";
        $resultadoInfo = ejecutarConsultaPreparada($sqlInfo, "i", [$idEliminar]);
        $info = $resultadoInfo->fetch_assoc();
        
        // Elimina el producto
        $sqlEliminar = "DELETE FROM producto WHERE idproducto = ?";
        $resultado = ejecutarConsultaPreparada($sqlEliminar, "i", [$idEliminar]);
        
        if ($resultado) {
            $mensaje = "Producto eliminado correctamente";
            $tipoMensaje = 'success';
            
            $datosSesion = obtenerDatosSesion();
            registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                       null, null, $idEliminar, null, 
                       "Producto eliminado: {$info['marca']} {$info['modelo']}");
        } else {
            $mensaje = "Error al eliminar el producto";
            $tipoMensaje = 'danger';
        }
    }
}

// Procesar CREAR/EDITAR
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idproducto = isset($_POST['idproducto']) ? (int)$_POST['idproducto'] : null;
    $marca = trim($_POST['marca']);
    $modelo = trim($_POST['modelo']);
    $categoria = trim($_POST['categoria']);
    
    // Validación
    if (empty($marca) || empty($modelo) || empty($categoria)) {
        $mensaje = "Todos los campos son obligatorios";
        $tipoMensaje = 'danger';
    } else {
        if ($idproducto) {
            // ACTUALIZAR
            $sql = "UPDATE producto SET marca = ?, modelo = ?, categoria = ? 
                    WHERE idproducto = ?";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $marca, $modelo, $categoria, $idproducto);
            $resultado = $stmt->execute();
            $stmt->close();
            
            if ($resultado) {
                $mensaje = "Producto actualizado correctamente";
                $tipoMensaje = 'success';
                
                $datosSesion = obtenerDatosSesion();
                registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                           null, null, $idproducto, null, 
                           "Producto actualizado: $marca $modelo");
            } else {
                $mensaje = "Error al actualizar el producto";
                $tipoMensaje = 'danger';
            }
        } else {
            // CREAR
            $sql = "INSERT INTO producto (marca, modelo, categoria) VALUES (?, ?, ?)";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $marca, $modelo, $categoria);
            $resultado = $stmt->execute();
            $nuevoId = $conn->insert_id;
            $stmt->close();
            
            if ($resultado) {
                $mensaje = "Producto creado correctamente";
                $tipoMensaje = 'success';
                
                $datosSesion = obtenerDatosSesion();
                registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                           null, null, $nuevoId, null, 
                           "Nuevo producto creado: $marca $modelo");
            } else {
                $mensaje = "Error al crear el producto";
                $tipoMensaje = 'danger';
            }
        }
    }
}

// ========== SECCIÓN 3: PAGINACIÓN ==========

$paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($paginaActual < 1) $paginaActual = 1;

$sqlTotal = "SELECT COUNT(*) as total FROM producto";
$resultadoTotal = ejecutarConsulta($sqlTotal);
$filaTotal = $resultadoTotal->fetch_assoc();
$totalRegistros = $filaTotal['total'];

$registrosPorPagina = REGISTROS_POR_PAGINA;
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);
$offset = ($paginaActual - 1) * $registrosPorPagina;

$sql = "SELECT p.*, 
        (SELECT COUNT(*) FROM maquinaproducto WHERE idproducto = p.idproducto) as maquinas_asignadas
        FROM producto p
        ORDER BY p.idproducto DESC
        LIMIT ? OFFSET ?";

$conn = conectarBD();
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $registrosPorPagina, $offset);
$stmt->execute();
$resultado = $stmt->get_result();
$stmt->close();

// Producto a editar
$productoEditar = null;
if (isset($_GET['accion']) && $_GET['accion'] === 'editar' && isset($_GET['id'])) {
    $idEditar = (int)$_GET['id'];
    $sqlEditar = "SELECT * FROM producto WHERE idproducto = ?";
    $resultadoEditar = ejecutarConsultaPreparada($sqlEditar, "i", [$idEditar]);
    if ($resultadoEditar) {
        $productoEditar = $resultadoEditar->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Gestión de Productos</title>
    <link rel="stylesheet" href="/topvending/css/estilos.css">
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .page-header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; 
                 background-color: rgba(0,0,0,0.5); overflow: auto; }
        .modal.show { display: block; }
        .modal-content { background-color: white; margin: 5% auto; padding: 30px; border-radius: 8px; 
                        width: 90%; max-width: 500px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-header h2 { margin: 0; }
        .close { font-size: 28px; font-weight: bold; color: #999; cursor: pointer; }
        .close:hover { color: #333; }
        
        .pagination { display: flex; justify-content: center; gap: 10px; margin-top: 30px; }
        .pagination a, .pagination span { padding: 8px 15px; background: white; border: 1px solid #ddd; 
                                         border-radius: 5px; text-decoration: none; color: #333; }
        .pagination a:hover { background: #667eea; color: white; }
        .pagination .active { background: #667eea; color: white; font-weight: bold; }
        
        .table-container { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden; }
        .info-paginacion { padding: 15px 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; color: #666; font-size: 14px; }
        
        .categoria-badge { padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; }
        .cat-refrescos { background: #dbeafe; color: #1e40af; }
        .cat-dulces { background: #fce7f3; color: #be185d; }
        .cat-frutos { background: #fef3c7; color: #92400e; }
        .cat-bebidas { background: #d1fae5; color: #065f46; }
        
        .btn-actions { display: flex; gap: 5px; }
        .btn-icon { padding: 6px 10px; font-size: 12px; }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <div class="page-header">
            <h1>🍫 Gestión de Productos</h1>
            <p>Administración del catálogo de productos disponibles</p>
        </div>
        
        <?php if ($mensaje): ?>
        <div class="alert alert-<?php echo $tipoMensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
        <?php endif; ?>
        
        <button onclick="mostrarModal()" class="btn btn-primary" style="margin-bottom: 20px;">
            ➕ Nuevo Producto
        </button>
        
        <div class="table-container">
            <div class="info-paginacion">
                Mostrando <?php echo $offset + 1; ?> - <?php echo min($offset + $registrosPorPagina, $totalRegistros); ?> 
                de <?php echo $totalRegistros; ?> productos
                | Página <?php echo $paginaActual; ?> de <?php echo $totalPaginas; ?>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Categoría</th>
                        <th>Máquinas Asignadas</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($producto = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $producto['idproducto']; ?></td>
                        <td><strong><?php echo htmlspecialchars($producto['marca']); ?></strong></td>
                        <td><?php echo htmlspecialchars($producto['modelo']); ?></td>
                        <td>
                            <?php 
                            $claseCat = 'cat-refrescos';
                            if ($producto['categoria'] === 'DULCES') $claseCat = 'cat-dulces';
                            if ($producto['categoria'] === 'FRUTOS SECOS') $claseCat = 'cat-frutos';
                            if ($producto['categoria'] === 'BEBIDAS CALIENTES') $claseCat = 'cat-bebidas';
                            ?>
                            <span class="categoria-badge <?php echo $claseCat; ?>">
                                <?php echo htmlspecialchars($producto['categoria']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge badge-info">
                                <?php echo $producto['maquinas_asignadas']; ?> máquina(s)
                            </span>
                        </td>
                        <td>
                            <div class="btn-actions">
                                <a href="?accion=editar&id=<?php echo $producto['idproducto']; ?>&pagina=<?php echo $paginaActual; ?>" 
                                   class="btn btn-secondary btn-icon">✏️ Editar</a>
                                <a href="?accion=eliminar&id=<?php echo $producto['idproducto']; ?>&pagina=<?php echo $paginaActual; ?>" 
                                   class="btn btn-danger btn-icon"
                                   onclick="return confirm('¿Está seguro de eliminar este producto?')">🗑️ Eliminar</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php if ($totalRegistros == 0): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">
                            No hay productos registrados
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($totalPaginas > 1): ?>
            <div class="pagination">
                <?php if ($paginaActual > 1): ?>
                    <a href="?pagina=<?php echo $paginaActual - 1; ?>">← Anterior</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                    <?php if ($i == $paginaActual): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($paginaActual < $totalPaginas): ?>
                    <a href="?pagina=<?php echo $paginaActual + 1; ?>">Siguiente →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal -->
    <div id="modalForm" class="modal <?php echo ($productoEditar ? 'show' : ''); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h2><?php echo $productoEditar ? 'Editar Producto' : 'Nuevo Producto'; ?></h2>
                <span class="close" onclick="cerrarModal()">&times;</span>
            </div>
            
            <form method="POST" action="?pagina=<?php echo $paginaActual; ?>">
                <?php if ($productoEditar): ?>
                <input type="hidden" name="idproducto" value="<?php echo $productoEditar['idproducto']; ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label>Marca *</label>
                    <input type="text" name="marca" class="form-control" required
                           value="<?php echo $productoEditar ? htmlspecialchars($productoEditar['marca']) : ''; ?>"
                           placeholder="Ej: COCACOLA">
                </div>
                
                <div class="form-group">
                    <label>Modelo *</label>
                    <input type="text" name="modelo" class="form-control" required
                           value="<?php echo $productoEditar ? htmlspecialchars($productoEditar['modelo']) : ''; ?>"
                           placeholder="Ej: Coke Classic">
                </div>
                
                <div class="form-group">
                    <label>Categoría *</label>
                    <select name="categoria" class="form-control" required>
                        <?php foreach (CATEGORIAS_PRODUCTO as $cat): ?>
                        <option value="<?php echo $cat; ?>" 
                                <?php echo ($productoEditar && $productoEditar['categoria'] === $cat) ? 'selected' : ''; ?>>
                            <?php echo $cat; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" onclick="cerrarModal()" class="btn btn-secondary">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <?php echo $productoEditar ? 'Actualizar' : 'Crear'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function mostrarModal() {
            document.getElementById('modalForm').classList.add('show');
        }
        
        function cerrarModal() {
            window.location.href = '?pagina=<?php echo $paginaActual; ?>';
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('modalForm');
            if (event.target == modal) {
                cerrarModal();
            }
        }
    </script>
</body>
</html>