-- v4: 04/12/2025 versión final para el trabajo 
DROP DATABASE IF EXISTS topvending;
CREATE DATABASE IF NOT EXISTS topvending;

USE topvending;



CREATE TABLE empleado(
		idempleado		INT 		AUTO_INCREMENT PRIMARY KEY
    ,	matricula 		VARCHAR(45)	NOT NULL
    ,   nombre 			VARCHAR(45)	NOT NULL
    ,	apellidos 		VARCHAR(45)	NOT NULL
    ,	dni 			VARCHAR(9)	NOT NULL
	,   email			VARCHAR(99) DEFAULT 'rrhh@topvending.com'
    ,	categoria 		VARCHAR(45)	NOT NULL
	,	estadolaboral	varchar(45)	NOT NULL
);
-- #1
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000A","Emilio","Fernandez","12345678A","RRHH","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000B","Maria","Aguilera","12345678B","Fabricacion","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000C","Wyllow","Gomes","12345678C","Suministros","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000D","Bernardo","Garcia","12345678D","Incidencias","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000E","Ramon","Merchan","12345678E","Calidad","activo");

INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("0000000000F","Javier","Zurita","82345678A","RRHH","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("00000000010","Unai","Ramirez","82345678B","Fabricacion","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("00000000011","Carlos","Vincent","82345678C","Suministros","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("00000000012","Aissa","Diallo","82345678D","Incidencias","activo");
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("00000000013","Stefanni","Anahi","82345678E","Calidad","activo");

-- #11
INSERT INTO empleado(matricula,nombre,apellidos,dni,categoria,estadolaboral) values("00000000007","RMS","VDP","82345678E","Admin","activo");


CREATE TABLE producto(
		idproducto	INT 		AUTO_INCREMENT PRIMARY KEY
	,	marca 		VARCHAR(32) NOT NULL
    ,	modelo 		VARCHAR(32) NOT NULL
    ,	categoria 	VARCHAR(32)	NOT NULL	-- Categorias contempladas : REFRESCOS, DULCES, FRUTOS SECOS, BEBIDAS CALIENTES
);

-- #1  
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Coke Classic','REFRESCOS');
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Coke Zero','REFRESCOS');
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Fanta Naranja','REFRESCOS');
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Fanta Limón','REFRESCOS');
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Nestea','REFRESCOS');
INSERT INTO producto (marca, modelo,categoria) values ('COCACOLA','Sprite','REFRESCOS');
-- #7
INSERT INTO producto (marca, modelo,categoria) values ('SAIMAZA','Cafe Expresso','BEBIDAS CALIENTES');
INSERT INTO producto (marca, modelo,categoria) values ('SAIMAZA','Cafe con Leche','BEBIDAS CALIENTES');
INSERT INTO producto (marca, modelo,categoria) values ('SAIMAZA','Cafe Capuchino','BEBIDAS CALIENTES');
INSERT INTO producto (marca, modelo,categoria) values ('SAIMAZA','Te Rojo','BEBIDAS CALIENTES');
-- #11
INSERT INTO producto (marca, modelo,categoria) values ('FINNI','Gominolas Fruit','DULCES');
INSERT INTO producto (marca, modelo,categoria) values ('FINNI','Ositos','DULCES');
INSERT INTO producto (marca, modelo,categoria) values ('TRIDENT','Fresa','DULCES');
INSERT INTO producto (marca, modelo,categoria) values ('TRIDENT','Menta','DULCES');
INSERT INTO producto (marca, modelo,categoria) values ('BORGES','Almendras','FRUTOS SECOS');
INSERT INTO producto (marca, modelo,categoria) values ('BORGES','Pipas con Sal','FRUTOS SECOS');
INSERT INTO producto (marca, modelo,categoria) values ('BORGES','Cacahuetes','FRUTOS SECOS');
-- Producto ficticio para indicar <sin producto> y respetar integridad referencial
INSERT INTO producto (idproducto,marca, modelo,categoria) values (0,'---','---','---');

CREATE TABLE estado(
		idestado	INT 		AUTO_INCREMENT PRIMARY KEY
	,	descripcion	VARCHAR(64)	NOT NULL	-- Valores permitidos : 'Averiada', 'en Servicio',  'Desactivada')
);

INSERT INTO estado (descripcion) values ('Averiada');
INSERT INTO estado (descripcion) values ('En Servicio');
INSERT INTO estado (descripcion) values ('Desactivada');


CREATE TABLE ubicacion(
		idubicacion	INT 		AUTO_INCREMENT PRIMARY KEY
	,	cliente		VARCHAR(64)	NOT NULL
	,	dir			VARCHAR(64) NOT NULL 	-- PARA METERLO EN MAPS
);

-- Dirección de la empresa operadora de las máquinas
-- #1
INSERT INTO ubicacion(cliente, dir) values ('TOP-VENDING','Pintor Rosales;15;28000;Madrid');
-- Direcciones de clientes del servicio
-- #2
INSERT INTO ubicacion(cliente, dir) values ('CORTE INGLES','Puerta del Sol;5;28000;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('CORTE INGLES','Avda. Libertad;54;28043;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('CORTE INGLES','Arguelles;154;28003;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('LAVAMATIC','Franciso Silvela;39;28010;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('LAVAMATIC','Juan Yuste;65;24010;Toledo');
INSERT INTO ubicacion(cliente, dir) values ('LAVAMATIC','Franciso Silvela;39;28010;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('LAVAMATIC','Ronda de Valencia;65;28003;Madrid');
INSERT INTO ubicacion(cliente, dir) values ('TELA,TELITA','Ronda Litoral;89;37041;Castellón');
INSERT INTO ubicacion(cliente, dir) values ('EL RÁPIDO','Juan Gris;157;25003;Barcelona');
INSERT INTO ubicacion(cliente, dir) values ('EL TRATO','Avinguda Diagonal;443;25008;Barcelona');

CREATE TABLE modelo(
        idmodelo INT AUTO_INCREMENT PRIMARY KEY
    ,   descripcion VARCHAR(32)
    ,   numfilas    INT
    ,   numcolumnas INT
	,   stockmax    INT  DEFAULT 20					-- CAPACIDAD MÁXIMA (FONDO DE CARGADOR)  
    ,	foto		VARCHAR(128)	NOT NULL		-- RUTA RELATIVA A DONDE ESTÁN LAS IMÁGENES
);

INSERT INTO modelo(idmodelo,descripcion,numfilas,numcolumnas,foto) values (1,'STAR24',4,6,'null');
INSERT INTO modelo(idmodelo,descripcion,numfilas,numcolumnas,foto) values (2,'STAR30',5,6,'null');
INSERT INTO modelo(idmodelo,descripcion,numfilas,numcolumnas,foto) values (3,'STAR42',7,6,'null');

CREATE TABLE maquina(
		idmaquina	INT 			AUTO_INCREMENT PRIMARY KEY
	,	numserie	VARCHAR(32)		NOT NULL
    ,	idestado	INT 			NOT NULL		-- FK DE ESTADO
    ,	idubicacion	INT 			NOT NULL		-- FK DE UBICACION
	-- LAS MÁQUINAS EN UBICACIÓN 1, SE ENCUENTRAN EN EL TALLER DE LA OPERADORA
    --  capacidad	INT				NOT NULL        -- NUMERO DE ARTICULOS DISTINTOS
    ,	idmodelo	INT 	                        -- MODELO : 2 -> STAR30 (5X6) ,1 -> STAR24 (4X6) , 3-> STAR42 (7X6)
    ,	FOREIGN KEY (idestado) 	  REFERENCES estado(idestado)
    ,	FOREIGN KEY (idubicacion) REFERENCES ubicacion(idubicacion)
);

-- #1,2,3
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN12345678',1,1,2); 
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN98765432',2,2,1); 
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN74185296',2,3,3); 
-- #4,5,6
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN87654321',2,5,2); 
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN00234567',2,6,1); 
INSERT INTO maquina(numserie, idestado, idubicacion, idmodelo) values ('SN99323232',2,7,3); 


CREATE TABLE maquinaproducto(
		id			INT AUTO_INCREMENT PRIMARY KEY
	,	idmaquina	INT NOT NULL					-- FK DE MAQUINA
	,	idproducto	INT	NOT NULL					-- FK DE PRODUCTO
	,	stock		INT DEFAULT 0					-- cargador vacío por defecto	
    ,   idfila      INT DEFAULT 0                   -- Fila donde se ubica el producto
    ,   idcolumna   INT DEFAULT 0                   -- Columna donde se ubica el producto
    ,	FOREIGN KEY (idmaquina)	 REFERENCES maquina(idmaquina)
    ,	FOREIGN KEY (idproducto) REFERENCES producto(idproducto)
);

-- maquina modelo
/*
	1		2
    2		1
    3		3
    4		2
    5		1
    6		3
*/
-- Datos para máquinas 1,2 y 3    
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(1,3,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(2,10,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(3,7,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(1,9,1,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(2,6,1,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(3,17,1,3,20);
-- Datos para máquina 4
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,1,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,2,1,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,3,1,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,4,1,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,5,1,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,6,1,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,7,2,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,8,2,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,9,2,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,10,2,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,11,2,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,12,2,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,13,3,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,14,3,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,15,3,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,16,3,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(4,17,3,5,20);
-- Datos para máquina 5
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,1,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,2,1,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,3,1,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,4,1,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,5,1,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,6,1,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,7,2,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,8,2,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,9,2,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,10,2,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,11,2,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,12,2,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,13,3,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,14,3,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,15,3,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,16,3,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(5,17,3,5,20);
-- Datos para máquina 6
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,1,1,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,2,1,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,3,1,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,4,1,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,5,1,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,6,1,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,8,2,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,9,2,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,10,2,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,11,2,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,12,2,5,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,13,2,6,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,15,3,1,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,16,3,2,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,7,3,3,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,7,3,4,20);
INSERT INTO maquinaproducto (idmaquina,idproducto,idfila,idcolumna,stock) values(6,7,3,5,20);

CREATE TABLE incidencias(
		idincidencia	INT 														AUTO_INCREMENT PRIMARY KEY
    ,	idmaquina		INT 														NOT NULL	-- FK DE MAQUINA
    ,	idproducto		INT 														NOT NULL 	-- FK DE PRODUCTO
    ,	idubicacion		int															NOT NULL	-- FK DE UBICACION
    ,	categoria		ENUM('Producto', 'Equipo', 'Red')							NOT NULL	-- Categoría de la incidencia :
																						-- 'Producto' : relacionada con los productos (sin stock, debajo del umbral, etc)
																						-- 'Equipo'   : relacionada con el funcionamiento del equipo : atasco, mensaje error algún componente
																						-- 'Red'      : cortes en la comunicación con la central o algún problema de conectividad
    ,	stock			INT 														NOT NULL
    ,	severidad		ENUM('ALTA', 'MEDIA', 'BAJA')								NOT NULL	
    ,	estado			ENUM('Registrada', 'Revisada', 'En curso', 'Solucionada')	NOT NULL	-- Valores permitidos : 'Registrada', 'Revisada', 'En curso', 'Solucionada'
    ,	descripcion		VARCHAR(128)												NOT NULL
    ,	fecharegistro	DATETIME													NOT NULL
    ,	fecharesolucion	DATETIME													NULL
	,	solucion		VARCHAR(128)												NULL
    ,	FOREIGN KEY (idmaquina)   REFERENCES maquina(idmaquina)
    ,	FOREIGN KEY (idproducto)  REFERENCES producto(idproducto)
    ,	FOREIGN KEY (idubicacion) REFERENCES ubicacion(idubicacion)
);


CREATE TABLE usuarios(
		idempleado		INT 		NOT NULL
	,	user			VARCHAR(32)	NOT NULL
    ,	pass			VARCHAR(64)	NOT NULL			-- CONTRASEÑA ENCRIPTADA
    ,	rol				VARCHAR(32) NOT NULL
    , 	FOREIGN KEY (idempleado) REFERENCES empleado(idempleado)
);


INSERT INTO usuarios values (11,'m0','pass','ADMIN');
INSERT INTO usuarios values (1,'m1','pass','RRHH');
INSERT INTO usuarios values (2,'m2','pass','FABRICACION');
INSERT INTO usuarios values (3,'m3','pass','SUMINISTROS');
INSERT INTO usuarios values (4,'m4','pass','INCIDENCIAS');
INSERT INTO usuarios values (5,'m5','pass','CALIDAD');

CREATE TABLE perfil(
		rol		VARCHAR(32)	NOT NULL					-- PERFIL DEL USUARIO
    ,	modulo	VARCHAR(8)	NOT NULL					-- MODULO AL QUE TIENE ACCESO
	,   titulo  VARCHAR(64) NOT NULL
);
INSERT INTO perfil(rol, modulo,titulo) values ('ADMIN','M0','TopVending ADMINISTRACIÓN');
INSERT INTO perfil(rol, modulo,titulo) values ('RRHH','M1','TopVending RECURSOS HUMANOS');
INSERT INTO perfil(rol, modulo,titulo) values ('FABRICACION','M2','TopVending FABRICACIÓN');
INSERT INTO perfil(rol, modulo,titulo) values ('SUMINISTROS','M3','TopVending SUMINISTROS');
INSERT INTO perfil(rol, modulo,titulo) values ('INCIDENCIAS','M4','TopVending INCIDENCIAS');
INSERT INTO perfil(rol, modulo,titulo) values ('CALIDAD','M5','TopVending INFORMES');


CREATE TABLE menu(
		idmenu	INT AUTO_INCREMENT 	PRIMARY KEY,
        modulo	VARCHAR(8)			NOT NULL,			-- MODULO AL QUE TIENE ACCESO (FK)
        rol     VARCHAR(32)			NOT NULL,			-- ROL (FK ALTERNATIVA)
		orden    INT 				NOT NULL,			-- ORDEN LA OPCIÓN
		boton   VARCHAR(24) 		NOT NULL,   		-- TEXTO DE LA OPCIÓN
		enlace  VARCHAR(128) 		DEFAULT '/mx/wip.php' -- PAGINA DE INICIO DEL MÓDULO
);
-- Creación de menús genéricos para pruebas de la aplicación
INSERT INTO menu (rol,modulo,orden,boton,enlace) values ('ADMIN','M0',1,'Log Auditoría','/mx/audit1.php');
/*
INSERT INTO menu (rol,modulo,orden,boton) values ('ADMIN','M0',2,'Sesiones');
INSERT INTO menu (rol,modulo,orden,boton) values ('ADMIN','M0',3,'Maquinas');
INSERT INTO menu (rol,modulo,orden,boton) values ('ADMIN','M0',4,'Incidencias');
*/
INSERT INTO menu (rol,modulo,orden,boton) values ('RRHH','M1',1,'Opcion 1');
INSERT INTO menu (rol,modulo,orden,boton) values ('RRHH','M1',2,'Opcion 2');
INSERT INTO menu (rol,modulo,orden,boton) values ('RRHH','M1',3,'Opcion 3');
INSERT INTO menu (rol,modulo,orden,boton) values ('RRHH','M1',4,'Opcion 4');

INSERT INTO menu (rol,modulo,orden,boton) values ('FABRICACION','M2',1,'Opcion 1');
INSERT INTO menu (rol,modulo,orden,boton) values ('FABRICACION','M2',2,'Opcion 2');
INSERT INTO menu (rol,modulo,orden,boton) values ('FABRICACION','M2',3,'Opcion 3');
INSERT INTO menu (rol,modulo,orden,boton) values ('FABRICACION','M2',4,'Opcion 4');

INSERT INTO menu (rol,modulo,orden,boton) values ('SUMINISTROS','M3',1,'Opcion 1');
INSERT INTO menu (rol,modulo,orden,boton) values ('SUMINISTROS','M3',2,'Opcion 2');
INSERT INTO menu (rol,modulo,orden,boton) values ('SUMINISTROS','M3',3,'Opcion 3');
INSERT INTO menu (rol,modulo,orden,boton) values ('SUMINISTROS','M3',4,'Opcion 4');

INSERT INTO menu (rol,modulo,orden,boton) values ('INCIDENCIAS','M4',1,'Opcion 1');
INSERT INTO menu (rol,modulo,orden,boton) values ('INCIDENCIAS','M4',2,'Opcion 2');
INSERT INTO menu (rol,modulo,orden,boton) values ('INCIDENCIAS','M4',3,'Opcion 3');
INSERT INTO menu (rol,modulo,orden,boton) values ('INCIDENCIAS','M4',4,'Opcion 4');

INSERT INTO menu (rol,modulo,orden,boton) values  ('CALIDAD','M5', 1,'Opcion 1');
INSERT INTO menu (rol,modulo,orden,boton) values  ('CALIDAD','M5', 2,'Opcion 2');
INSERT INTO menu (rol,modulo,orden,boton) values  ('CALIDAD','M5', 3,'Opcion 3');
INSERT INTO menu (rol,modulo,orden,boton) values  ('CALIDAD','M5', 4,'Opcion 4');
/*
-------------------------------------------------------------------------------------------------------------
Esta tabla se crea a partir de los registros de log que se almacenan en el archivo de log.

Existirá un proceso que la genere. La entrada del archivo se procesa
y se compone en un formato único, que dependiendo de la naturaleza del
evento podrá contener o no valores no nulos para algunos campos.
Sólo si el evento  hace referencia a una incidencia el identificador
de incidencia tendrá un valor no nulo.
Igualmente si el registro tiene que ver con una acción sobre un producto concreto
aparecerá el valor de su identificador y sus unidades ( consumidas o respuestas por ejemplo)
El campo descripción está en un formato entendible por el usuario.

-------------------------------------------------------------------------------------------------------------
*/

CREATE TABLE log (

id			int	auto_increment primary KEY,
categoria	enum 			('ERROR','WARNING','INFO'),
idempleado 	int				null,		-- Identificador único del empleado
rol			varchar(32)		null,		-- rol del empleado/usuario
idmaquina 	int				null,		-- Identificador único de la maquina
idincidencia int			null,		-- Identificador único de la incidencia
idproducto 	int				null,		-- Identificadtor único del producto
uds			int				null,		-- Venta realizada del producto
fechareg	timestamp		not null,	-- Fecha de registro de log
descripcion	varchar(128)	null		-- Descripción del registro de log
);

/*
-------------------------------------------------------------------------------------------------------------
DE UTILIDAD:
Vista para facilitar la presentación de resultados en formato tabular
-------------------------------------------------------------------------------------------------------------

*/
create view log_chachi as 
SELECT id, l.fechareg as Fecha, l.categoria as Tipo, concat(e.apellidos,', ',e.nombre) as Empleado,
u.user, l.rol as Modulo, m.numserie as NSerie, p.modelo as Producto,l.uds as Unidades,l.descripcion as Descripion
FROM topvending.log as l
LEFT JOIN empleado e ON e.idempleado = l.idempleado
LEFT JOIN maquina m ON m.idmaquina = l.idmaquina
LEFT JOIN usuarios u ON l.idempleado = u.idempleado
LEFT JOIN producto p ON l.idproducto = p.idproducto
;

create view v_maquina as
select m.idmaquina,m.numserie,t.descripcion modelo ,u.cliente,e.descripcion estado
from maquina m
inner join modelo t on m.idmodelo=t.idmodelo
inner join ubicacion u on u.idubicacion = m.idubicacion
inner join estado e on e.idestado=m.idestado
;

/*
DATOS DE EJEMPLO PARA LA RESULUCIÓN DE LAS CUESTIONES DEL EXAMEN
*/

INSERT INTO log (categoria ,idempleado,rol           ,idmaquina,idincidencia,idproducto,uds,fechareg ,descripcion)
VALUES          ('INFO'    ,1         ,'SUMINISTROS' ,1        ,NULL        ,1      ,10    ,'2024-11-24 00:00:01'    ,'Reposición de producto'),
				('ERROR'   ,NULL      ,NULL          ,2        ,1024        ,NULL   ,NULL  ,'2024-11-25 00:00:02'    ,'Maquina averiada'),
                ('WARNING' ,3         ,'RRHH'        ,5        ,NULL        ,6      ,5     ,'2024-11-26 00:00:03'    ,'Alcanzado umbral de reposición'),
                ('INFO'    ,2         ,'SUMINISTROS' ,3        ,NULL        ,2      ,10    ,'2024-11-27 00:00:04'    ,'Reposición de producto'),
				('ERROR'   ,NULL      ,NULL          ,2        ,8943        ,NULL   ,NULL  ,'2024-11-28 00:00:05'    ,'Pierde conexión con central'),
                ('INFO'    ,7         ,'FABRICACION' ,5        ,NULL        ,NULL   ,NULL  ,'2024-11-29 00:00:06'    ,'Maquina asignada a cliente');
