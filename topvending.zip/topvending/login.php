<?php
/**
 * CORREGIDO: Sin bucles de redirección
 */

require_once __DIR__ . '/clases/basedatos.php';
require_once __DIR__ . '/clases/sesion.php';
require_once __DIR__ . '/clases/log.php';

// Si ya está logueado, redirige a su módulo
if (verificarSesion()) {
    $datos = obtenerDatosSesion();
    $moduloRuta = strtolower($datos['modulo']);
    
    // Ruta ABSOLUTA con barra inicial
    header("Location: /topvending/$moduloRuta/index.php");
    exit();
}

$error = '';
$timeout = isset($_GET['timeout']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($usuario) || empty($password)) {
        $error = 'Usuario y contraseña obligatorios';
    } else {
        $sql = "SELECT u.idempleado, u.user, u.pass, u.rol, p.modulo 
                FROM usuarios u
                INNER JOIN perfil p ON u.rol = p.rol
                WHERE u.user = ? LIMIT 1";
        
        $resultado = ejecutarConsultaPreparada($sql, "s", [$usuario]);
        
        if ($resultado && $fila = $resultado->fetch_assoc()) {
            if ($password === $fila['pass']) {
                crearSesion($fila['user'], $fila['idempleado'], 
                           $fila['rol'], $fila['modulo']);
                
                $moduloRuta = strtolower($fila['modulo']);
                
                $destino = isset($_SESSION['url_destino']) 
                    ? $_SESSION['url_destino'] 
                    : "/topvending/$moduloRuta/index.php";
                
                unset($_SESSION['url_destino']);
                
                // Ruta ABSOLUTA
                header("Location: $destino");
                exit();
            } else {
                $error = 'Usuario o contraseña incorrectos';
                registrarLog('WARNING', null, null, null, null, null, null,
                            "Intento fallido: $usuario");
            }
        } else {
            $error = 'Usuario o contraseña incorrectos';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: #333;
            margin: 0 0 10px 0;
            font-size: 28px;
        }
        
        .login-header p {
            color: #666;
            font-size: 14px;
        }
        
        .alert {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-error {
            background-color: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-info {
            background-color: #e7f3ff;
            color: #0066cc;
            border: 1px solid #b3d9ff;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #999;
        }
        
        .usuarios-prueba {
            background: #f9f9f9;
            padding: 12px;
            border-radius: 5px;
            margin-top: 15px;
            border: 1px solid #e0e0e0;
        }
        
        .usuarios-prueba h4 {
            margin: 0 0 8px 0;
            color: #333;
            font-size: 13px;
        }
        
        .usuarios-prueba p {
            margin: 4px 0;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔷 TopVending</h1>
            <p>Sistema de Gestión de Máquinas</p>
        </div>
        
        <?php if ($timeout): ?>
            <div class="alert alert-info">
                Su sesión ha expirado. Por favor, inicie sesión nuevamente.
            </div>
        <?php endif; ?>
        
        <?php if ($error && !$timeout): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="usuario">Usuario</label>
                <input 
                    type="text" 
                    id="usuario" 
                    name="usuario" 
                    required 
                    autofocus
                    placeholder="Ingrese su usuario"
                >
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    required
                    placeholder="Ingrese su contraseña"
                >
            </div>
            
            <button type="submit" class="btn-login">
                Iniciar Sesión
            </button>
        </form>
        
        <div class="usuarios-prueba">
            <h4>👤 Usuarios de Prueba:</h4>
            <p><strong>Admin:</strong> m0 / pass</p>
            <p><strong>Suministros:</strong> m3 / pass</p>
        </div>
        
        <div class="login-footer">
            <p>&copy; 2025 TopVending</p>
        </div>
    </div>
</body>
</html>