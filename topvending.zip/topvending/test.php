<?php
echo "<h1>🔍 Diagnóstico TopVending</h1>";

// 1. Verifica PHP
echo "<h2>✅ PHP Funcionando</h2>";
echo "<p>Versión PHP: " . phpversion() . "</p>";

// 2. Verifica conexión BD
require_once 'clases/basedatos.php';

try {
    $resultado = ejecutarConsulta("SELECT COUNT(*) as total FROM maquina");
    $fila = $resultado->fetch_assoc();
    echo "<h2>✅ Base de Datos OK</h2>";
    echo "<p>Máquinas en BD: " . $fila['total'] . "</p>";
    
    // 3. Verifica usuarios
    $resultado = ejecutarConsulta("SELECT COUNT(*) as total FROM usuarios");
    $fila = $resultado->fetch_assoc();
    echo "<p>Usuarios en BD: " . $fila['total'] . "</p>";
    
    // 4. Verifica menús
    $resultado = ejecutarConsulta("SELECT COUNT(*) as total FROM menu");
    $fila = $resultado->fetch_assoc();
    echo "<p>Opciones de menú: " . $fila['total'] . "</p>";
    
    echo "<h2>✅ Todo funcionando correctamente</h2>";
    echo "<p><a href='login.php'>Ir al Login →</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Error de Conexión</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?>
```

---

## 🧪 VERIFICACIÓN COMPLETA

### 1. **Verifica la ruta**
Abre: http://localhost/topvending/test.php

**Debe mostrar:**
```
✅ PHP Funcionando
✅ Base de Datos OK
✅ Todo funcionando correctamente
```

### 2. **Prueba el login**
Abre: http://localhost/topvending/

**Debe mostrar:**
- Formulario de login
- Lista de usuarios de prueba

### 3. **Prueba autenticación**
- Usuario: `m0`
- Password: `pass`

**Debe:**
- Redirigir a `/m0/index.php`
- Mostrar dashboard admin

---

## 📋 CHECKLIST DE VERIFICACIÓN

- [ ] Ruta correcta: `C:\xampp\htdocs\topvending\`
- [ ] Apache iniciado en XAMPP
- [ ] MySQL iniciado en XAMPP
- [ ] Base de datos `topvending` existe
- [ ] Tablas creadas (maquina, producto, usuarios, menu, etc.)
- [ ] Archivo test.php funciona
- [ ] Login muestra formulario
- [ ] Carpeta /log/ existe y tiene permisos de escritura
- [ ] Archivo /log/log.txt existe (vacío)

---

## 🆘 SI AÚN HAY ERROR

Si después de todo sigue sin funcionar, dame esta información:

1. **URL exacta que intentas abrir:**
```
   http://localhost/...
```

2. **Ruta completa de tu carpeta:**
```
   C:\xampp\htdocs\...