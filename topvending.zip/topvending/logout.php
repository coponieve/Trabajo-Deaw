<?php
/**
 * Archivo: /topvending/logout.php
 * Propósito: Cerrar sesión del usuario
 * Funcionalidad: Destruye la sesión y redirige a login
 */

require_once __DIR__ . '/clases/sesion.php';

// Cierra la sesión del usuario
cerrarSesion();

// Redirige a la página de login
header("Location: /topvending/login.php");
exit();
?>