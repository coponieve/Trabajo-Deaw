<?php
/**
 * Archivo: /topvending/m3/monitorizar.php
 * Propósito: Página de monitorización visual de máquinas
 * Funcionalidad: Muestra estado en tiempo real con matriz de productos
 */

// SECCIÓN 1: Includes y verificación
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/menu.php';
require_once __DIR__ . '/clases/Maquina.php';

requiereSesion();
verificarTimeout(30);

if (!verificarRol(['ADMIN', 'SUMINISTROS'])) {
    die('Acceso denegado');
}

// SECCIÓN 2: Procesamiento de filtros y selección
$clientes = Maquina::obtenerClientes();
$modelos = Maquina::obtenerModelos();

// Filtros aplicados
$clienteSeleccionado = $_GET['cliente'] ?? '';
$modeloSeleccionado = $_GET['modelo'] ?? '';
$idMaquinaSeleccionada = $_GET['id'] ?? null;

// Obtiene máquinas según filtros
$maquinas = [];
if ($clienteSeleccionado && $modeloSeleccionado) {
    // Filtra por cliente y modelo
    $todasMaquinas = Maquina::obtenerTodas();
    foreach ($todasMaquinas as $maq) {
        if ($maq->getCliente() === $clienteSeleccionado && 
            $maq->getModelo() === $modeloSeleccionado) {
            $maquinas[] = $maq;
        }
    }
} elseif ($clienteSeleccionado) {
    $maquinas = Maquina::obtenerPorCliente($clienteSeleccionado);
} elseif ($modeloSeleccionado) {
    $maquinas = Maquina::obtenerPorModelo($modeloSeleccionado);
} else {
    $maquinas = Maquina::obtenerTodas();
}

// Máquina a mostrar
$maquinaActual = null;
if ($idMaquinaSeleccionada) {
    $maquinaActual = Maquina::obtenerPorId($idMaquinaSeleccionada);
} elseif (!empty($maquinas)) {
    $maquinaActual = $maquinas[0];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Monitorización</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Panel de filtros */
        .filters-panel {
            background: white;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .filters-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }
        
        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 8px;
            color: #666;
            font-size: 14px;
            font-weight: 500;
        }
        
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            background: white;
            cursor: pointer;
        }
        
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn-filter {
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }
        
        /* Panel principal */
        .monitor-panel {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        /* Información de máquina */
        .machine-info {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
            padding-bottom: 30px;
            border-bottom: 2px solid #e5e7eb;
        }
        
        .info-section h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .info-item {
            padding: 12px;
            background: #f9fafb;
            border-radius: 5px;
        }
        
        .info-item label {
            display: block;
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .info-item span {
            display: block;
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }
        
        /* Indicadores de estado */
        .status-indicators {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .indicator {
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        
        .indicator-title {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            text-transform: uppercase;
            font-weight: 600;
        }
        
        .indicator-value {
            font-size: 18px;
            font-weight: bold;
        }
        
        .indicator.online {
            background-color: #d1fae5;
            border: 2px solid #10b981;
        }
        
        .indicator.online .indicator-value {
            color: #065f46;
        }
        
        .indicator.offline {
            background-color: #fee2e2;
            border: 2px solid #ef4444;
        }
        
        .indicator.offline .indicator-value {
            color: #991b1b;
        }
        
        /* Matriz de productos */
        .matrix-container {
            margin-top: 30px;
        }
        
        .matrix-title {
            font-size: 20px;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .vending-matrix {
            display: table;
            margin: 0 auto;
            border-collapse: separate;
            border-spacing: 10px;
        }
        
        .matrix-row {
            display: table-row;
        }
        
        .matrix-cell {
            display: table-cell;
            width: 120px;
            height: 120px;
            border: 3px solid #e5e7eb;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            position: relative;
            background: white;
            transition: all 0.3s;
        }
        
        .matrix-cell:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        /* Colores según stock */
        .matrix-cell.stock-empty {
            background: #fee2e2;
            border-color: #ef4444;
        }
        
        .matrix-cell.stock-low {
            background: #fef3c7;
            border-color: #f59e0b;
        }
        
        .matrix-cell.stock-ok {
            background: #d1fae5;
            border-color: #10b981;
        }
        
        .matrix-cell.stock-empty {
            background: #f3f4f6;
            border-color: #d1d5db;
        }
        
        .cell-position {
            position: absolute;
            top: 5px;
            left: 8px;
            font-size: 11px;
            color: #999;
            font-weight: 600;
        }
        
        .cell-brand {
            font-size: 12px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        
        .cell-product {
            font-size: 11px;
            color: #666;
            margin-bottom: 8px;
        }
        
        .cell-stock {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }
        
        .cell-stock-label {
            font-size: 10px;
            color: #999;
        }
        
        /* Leyenda */
        .legend {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .legend-color {
            width: 30px;
            height: 30px;
            border-radius: 5px;
            border: 2px solid #ddd;
        }
        
        .legend-color.empty {
            background: #fee2e2;
            border-color: #ef4444;
        }
        
        .legend-color.low {
            background: #fef3c7;
            border-color: #f59e0b;
        }
        
        .legend-color.ok {
            background: #d1fae5;
            border-color: #10b981;
        }
        
        .legend-text {
            font-size: 14px;
            color: #666;
        }
        
        /* Botones de acción */
        .actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        /* Mensaje cuando no hay máquina */
        .no-machine {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .no-machine h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <!-- Panel de filtros -->
        <div class="filters-panel">
            <h3 class="filters-title">🔍 Filtros de Búsqueda</h3>
            
            <form method="GET" action="">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label>Cliente</label>
                        <select name="cliente" id="cliente">
                            <option value="">Todos los clientes</option>
                            <?php foreach ($clientes as $cliente): ?>
                            <option value="<?php echo htmlspecialchars($cliente); ?>"
                                    <?php echo ($cliente === $clienteSeleccionado) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cliente); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Modelo</label>
                        <select name="modelo" id="modelo">
                            <option value="">Todos los modelos</option>
                            <?php foreach ($modelos as $modelo): ?>
                            <option value="<?php echo $modelo; ?>"
                                    <?php echo ($modelo === $modeloSeleccionado) ? 'selected' : ''; ?>>
                                <?php echo $modelo; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <?php if (!empty($maquinas)): ?>
                    <div class="filter-group">
                        <label>Máquina</label>
                        <select name="id" id="maquina">
                            <?php foreach ($maquinas as $maq): ?>
                            <option value="<?php echo $maq->getIdMaquina(); ?>"
                                    <?php echo ($maquinaActual && $maq->getIdMaquina() === $maquinaActual->getIdMaquina()) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($maq->getNumSerie() . ' - ' . $maq->getCliente()); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                
                <button type="submit" class="btn-filter">Aplicar Filtros</button>
            </form>
        </div>
        
        <!-- Panel de monitorización -->
        <?php if ($maquinaActual): ?>
        <div class="monitor-panel">
            <!-- Información de la máquina -->
            <div class="machine-info">
                <div class="info-section">
                    <h2>📦 Información de la Máquina</h2>
                    <div class="info-grid">
                        <div class="info-item">
                            <label>Número de Serie</label>
                            <span><?php echo htmlspecialchars($maquinaActual->getNumSerie()); ?></span>
                        </div>
                        <div class="info-item">
                            <label>Modelo</label>
                            <span><?php echo htmlspecialchars($maquinaActual->getModelo()); ?></span>
                        </div>
                        <div class="info-item">
                            <label>Cliente</label>
                            <span><?php echo htmlspecialchars($maquinaActual->getCliente()); ?></span>
                        </div>
                        <div class="info-item">
                            <label>Ubicación</label>
                            <span><?php echo htmlspecialchars($maquinaActual->getDireccion()); ?></span>
                        </div>
                        <div class="info-item">
                            <label>Capacidad</label>
                            <span><?php echo $maquinaActual->getCapacidad(); ?> productos</span>
                        </div>
                        <div class="info-item">
                            <label>Stock Máximo</label>
                            <span><?php echo $maquinaActual->getStockMax(); ?> uds/producto</span>
                        </div>
                    </div>
                </div>
                
                <!-- Indicadores de estado -->
                <div class="status-indicators">
                    <?php if ($maquinaActual->estaEnServicio()): ?>
                    <div class="indicator online">
                        <div class="indicator-title">🟢 Estado de Servicio</div>
                        <div class="indicator-value">EN LÍNEA</div>
                    </div>
                    <?php else: ?>
                    <div class="indicator offline">
                        <div class="indicator-title">🔴 Estado de Servicio</div>
                        <div class="indicator-value">FUERA DE LÍNEA</div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($maquinaActual->tieneIncidencias()): ?>
                    <div class="indicator offline">
                        <div class="indicator-title">⚠️ Incidencias</div>
                        <div class="indicator-value">CON INCIDENCIAS</div>
                    </div>
                    <?php else: ?>
                    <div class="indicator online">
                        <div class="indicator-title">✅ Incidencias</div>
                        <div class="indicator-value">SIN INCIDENCIAS</div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Matriz de productos -->
            <div class="matrix-container">
                <h3 class="matrix-title">🎰 Estado de Stock por Posición</h3>
                
                <div class="vending-matrix">
                    <?php 
                    $matriz = $maquinaActual->obtenerMatriz();
                    foreach ($matriz as $fila): 
                    ?>
                    <div class="matrix-row">
                        <?php foreach ($fila as $celda): ?>
                        <div class="matrix-cell 
                            <?php 
                            if (isset($celda['vacia'])) {
                                echo 'stock-empty';
                            } elseif ($celda['stock'] <= 2) {
                                echo 'stock-empty';
                            } elseif ($celda['porcentaje'] < 20) {
                                echo 'stock-low';
                            } else {
                                echo 'stock-ok';
                            }
                            ?>">
                            
                            <div class="cell-position">#<?php echo $celda['posicion']; ?></div>
                            
                            <?php if (!isset($celda['vacia'])): ?>
                                <div class="cell-brand"><?php echo htmlspecialchars($celda['marca']); ?></div>
                                <div class="cell-product"><?php echo htmlspecialchars($celda['modelo']); ?></div>
                                <div class="cell-stock">
                                    <?php echo $celda['stock']; ?>
                                    <span class="cell-stock-label">/<?php echo $celda['stockmax']; ?></span>
                                </div>
                            <?php else: ?>
                                <div style="padding-top: 30px; color: #999;">Vacía</div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Leyenda -->
                <div class="legend">
                    <div class="legend-item">
                        <div class="legend-color ok"></div>
                        <span class="legend-text">Stock OK (>20%)</span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-color low"></div>
                        <span class="legend-text">Stock Bajo (<20%)</span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-color empty"></div>
                        <span class="legend-text">Sin Stock (≤2 uds)</span>
                    </div>
                </div>
            </div>
            
            <!-- Botones de acción -->
            <div class="actions">
                <a href="index.php" class="btn btn-secondary">← Volver al Dashboard</a>
                <button onclick="location.reload()" class="btn btn-primary">🔄 Actualizar Estado</button>
            </div>
        </div>
        
        <?php else: ?>
        <div class="monitor-panel">
            <div class="no-machine">
                <h3>😕 No hay máquinas disponibles</h3>
                <p>Selecciona diferentes filtros o verifica que existan máquinas registradas</p>
                <br>
                <a href="index.php" class="btn btn-primary">← Volver al Dashboard</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>