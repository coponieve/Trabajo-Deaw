<?php
/**
 * Archivo: /topvending/m3/simulador_consumos.php
 * Propósito: Simula consumos automáticos en las máquinas
 * Uso: Ejecutar periódicamente (cron, task scheduler, o llamada AJAX)
 * 
 * Este script simula que las máquinas venden productos de forma aleatoria
 * actualizando el stock y generando incidencias cuando es necesario
 */

require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/log.php';
require_once __DIR__ . '/clases/Maquina.php';

/**
 * Función: simularConsumo($idmaquina)
 * Propósito: Simula el consumo de productos en una máquina
 * 
 * Parámetros: $idmaquina - ID de la máquina a simular
 * 
 * Lógica:
 *   1. Obtiene productos de la máquina
 *   2. Selecciona productos al azar (0-3 productos por ejecución)
 *   3. Reduce stock de 1-3 unidades por producto
 *   4. Genera incidencias si stock < 2 unidades
 *   5. Registra la venta en el log
 */
function simularConsumo($idmaquina) {
    $maquina = Maquina::obtenerPorId($idmaquina);
    
    if (!$maquina) {
        return ['error' => 'Máquina no encontrada'];
    }
    
    // Solo simula consumo si la máquina está en servicio
    if (!$maquina->estaEnServicio()) {
        return ['mensaje' => 'Máquina no está en servicio'];
    }
    
    $productos = $maquina->getProductos();
    
    if (empty($productos)) {
        return ['mensaje' => 'Máquina sin productos'];
    }
    
    // Número aleatorio de productos a consumir (0-3)
    // rand() genera un número aleatorio entre los valores dados
    $numConsumosAleatorios = rand(0, 3);
    
    $consumos = [];
    
    for ($i = 0; $i < $numConsumosAleatorios; $i++) {
        // Selecciona un producto aleatorio
        // array_rand() retorna una clave aleatoria del array
        $indiceAleatorio = array_rand($productos);
        $producto = $productos[$indiceAleatorio];
        
        // Solo consume si hay stock disponible
        if ($producto['stock'] > 0) {
            // Cantidad a consumir (1-3 unidades)
            $cantidad = rand(1, min(3, $producto['stock']));
            
            // Actualiza el stock (cantidad negativa = resta)
            $maquina->actualizarStock($producto['idproducto'], -$cantidad);
            
            // Registra el consumo
            $consumos[] = [
                'producto' => $producto['marca'] . ' ' . $producto['modelo'],
                'cantidad' => $cantidad,
                'stock_restante' => $producto['stock'] - $cantidad
            ];
            
            // Registra en el log
            registrarLog('INFO', null, 'SISTEMA', $idmaquina, null, 
                        $producto['idproducto'], $cantidad, 
                        "Venta simulada: {$producto['marca']} {$producto['modelo']}");
            
            // Verifica si debe generar incidencia por stock bajo
            $stockRestante = $producto['stock'] - $cantidad;
            
            if ($stockRestante <= 2 && $stockRestante > 0) {
                // Stock bajo: genera incidencia de severidad MEDIA
                generarIncidencia($idmaquina, $producto['idproducto'], 
                                $stockRestante, 'MEDIA', 
                                "Stock bajo: {$producto['marca']} {$producto['modelo']} ({$stockRestante} uds)");
            } elseif ($stockRestante == 0) {
                // Stock agotado: genera incidencia de severidad ALTA
                generarIncidencia($idmaquina, $producto['idproducto'], 
                                $stockRestante, 'ALTA', 
                                "Producto agotado: {$producto['marca']} {$producto['modelo']}");
            }
        }
    }
    
    return [
        'exito' => true,
        'maquina' => $maquina->getNumSerie(),
        'consumos' => $consumos
    ];
}

/**
 * Función: generarIncidencia($idmaquina, $idproducto, $stock, $severidad, $descripcion)
 * Propósito: Crea una incidencia de tipo "Producto" en la BD
 * 
 * Parámetros:
 *   $idmaquina - ID de la máquina
 *   $idproducto - ID del producto afectado
 *   $stock - Stock actual del producto
 *   $severidad - 'ALTA', 'MEDIA' o 'BAJA'
 *   $descripcion - Descripción de la incidencia
 */
function generarIncidencia($idmaquina, $idproducto, $stock, $severidad, $descripcion) {
    // Primero verifica si ya existe una incidencia similar no resuelta
    // Esto evita duplicar incidencias
    $sqlVerificar = "SELECT COUNT(*) as total FROM incidencias 
                     WHERE idmaquina = ? 
                     AND idproducto = ? 
                     AND estado != 'Solucionada'";
    
    $resultado = ejecutarConsultaPreparada($sqlVerificar, "ii", [$idmaquina, $idproducto]);
    
    if ($resultado) {
        $fila = $resultado->fetch_assoc();
        if ($fila['total'] > 0) {
            // Ya existe una incidencia pendiente para este producto
            return false;
        }
    }
    
    // Obtiene la ubicación de la máquina
    $sqlUbicacion = "SELECT idubicacion FROM maquina WHERE idmaquina = ?";
    $resultadoUbic = ejecutarConsultaPreparada($sqlUbicacion, "i", [$idmaquina]);
    
    if (!$resultadoUbic) {
        return false;
    }
    
    $filaUbic = $resultadoUbic->fetch_assoc();
    $idubicacion = $filaUbic['idubicacion'];
    
    // Inserta la nueva incidencia
    $sql = "INSERT INTO incidencias 
            (idmaquina, idproducto, idubicacion, categoria, stock, 
             severidad, estado, descripcion, fecharegistro) 
            VALUES (?, ?, ?, 'Producto', ?, ?, 'Registrada', ?, NOW())";
    
    $conn = conectarBD();
    $stmt = $conn->prepare($sql);
    
    // Tipos de parámetros: i=integer, s=string
    $stmt->bind_param("iiiiss", 
        $idmaquina,      // i
        $idproducto,     // i
        $idubicacion,    // i
        $stock,          // i
        $severidad,      // s
        $descripcion     // s
    );
    
    $resultado = $stmt->execute();
    $stmt->close();
    
    if ($resultado) {
        // Registra en el log
        registrarLog('WARNING', null, 'SISTEMA', $idmaquina, null, 
                    $idproducto, null, "Incidencia generada: $descripcion");
    }
    
    return $resultado;
}

/**
 * Función: simularTodasLasMaquinas()
 * Propósito: Ejecuta la simulación para todas las máquinas en servicio
 * Retorna: Array con el resultado de cada máquina
 */
function simularTodasLasMaquinas() {
    $maquinas = Maquina::obtenerTodas();
    $resultados = [];
    
    foreach ($maquinas as $maquina) {
        // Solo simula máquinas en servicio
        if ($maquina->estaEnServicio()) {
            $resultado = simularConsumo($maquina->getIdMaquina());
            $resultados[] = $resultado;
        }
    }
    
    return $resultados;
}

/**
 * Función: simularConectividad($idmaquina)
 * Propósito: Simula pérdida de conectividad aleatoria
 * 
 * Lógica:
 *   - 95% de probabilidad: máquina mantiene conectividad
 *   - 5% de probabilidad: máquina pierde conectividad
 * 
 * Si pierde conectividad, genera incidencia tipo "Red"
 */
function simularConectividad($idmaquina) {
    // rand(1, 100) genera número entre 1 y 100
    // Si es <= 5 (5% probabilidad), pierde conectividad
    $pierdeConectividad = rand(1, 100) <= 5;
    
    if ($pierdeConectividad) {
        $maquina = Maquina::obtenerPorId($idmaquina);
        
        if (!$maquina) {
            return false;
        }
        
        // Verifica si ya existe incidencia de red
        $sql = "SELECT COUNT(*) as total FROM incidencias 
                WHERE idmaquina = ? 
                AND categoria = 'Red' 
                AND estado != 'Solucionada'";
        
        $resultado = ejecutarConsultaPreparada($sql, "i", [$idmaquina]);
        
        if ($resultado) {
            $fila = $resultado->fetch_assoc();
            if ($fila['total'] > 0) {
                // Ya existe incidencia de red
                return false;
            }
        }
        
        // Crea incidencia de red
        $sqlUbicacion = "SELECT idubicacion FROM maquina WHERE idmaquina = ?";
        $resultadoUbic = ejecutarConsultaPreparada($sqlUbicacion, "i", [$idmaquina]);
        $filaUbic = $resultadoUbic->fetch_assoc();
        
        $sqlIncidencia = "INSERT INTO incidencias 
                         (idmaquina, idproducto, idubicacion, categoria, stock, 
                          severidad, estado, descripcion, fecharegistro) 
                         VALUES (?, 1, ?, 'Red', 0, 'ALTA', 'Registrada', 
                                'Pérdida de conectividad con central', NOW())";
        
        $conn = conectarBD();
        $stmt = $conn->prepare($sqlIncidencia);
        $stmt->bind_param("ii", $idmaquina, $filaUbic['idubicacion']);
        $resultado = $stmt->execute();
        $stmt->close();
        
        if ($resultado) {
            registrarLog('ERROR', null, 'SISTEMA', $idmaquina, null, null, null,
                        "Máquina {$maquina->getNumSerie()} perdió conectividad");
        }
        
        return true;
    }
    
    return false;
}

// ========== EJECUCIÓN DEL SCRIPT ==========

// Determina el modo de ejecución
$modo = $_GET['modo'] ?? 'una'; // 'una' o 'todas'
$idmaquina = $_GET['id'] ?? null;

// Header para indicar que es JSON
header('Content-Type: application/json');

// Ejecuta según el modo
if ($modo === 'todas') {
    // Simula todas las máquinas
    $resultados = simularTodasLasMaquinas();
    
    // También simula conectividad aleatoria
    $maquinas = Maquina::obtenerTodas();
    foreach ($maquinas as $maquina) {
        if ($maquina->estaEnServicio()) {
            simularConectividad($maquina->getIdMaquina());
        }
    }
    
    echo json_encode([
        'exito' => true,
        'mensaje' => 'Simulación completada para todas las máquinas',
        'resultados' => $resultados
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} elseif ($modo === 'una' && $idmaquina) {
    // Simula una máquina específica
    $resultado = simularConsumo($idmaquina);
    simularConectividad($idmaquina);
    
    echo json_encode($resultado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} else {
    // Error: parámetros incorrectos
    echo json_encode([
        'error' => 'Parámetros incorrectos',
        'uso' => [
            'todas' => 'simulador_consumos.php?modo=todas',
            'una' => 'simulador_consumos.php?modo=una&id=1'
        ]
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

/**
 * INSTRUCCIONES DE USO:
 * 
 * 1. Llamada manual desde navegador:
 *    http://localhost/topvending/m3/simulador_consumos.php?modo=todas
 * 
 * 2. Llamada AJAX desde JavaScript (para auto-refrescar):
 *    fetch('/topvending/m3/simulador_consumos.php?modo=todas')
 *      .then(response => response.json())
 *      .then(data => console.log(data));
 * 
 * 3. Tarea programada (cron en Linux):
 *    5 * * * * php /var/www/html/topvending/m3/simulador_consumos.php?modo=todas
 *    (ejecuta cada 5 minutos)
 * 
 * 4. Tarea programada (Windows Task Scheduler):
 *    Programa: php.exe
 *    Argumentos: C:\xampp\htdocs\topvending\m3\simulador_consumos.php modo=todas
 *    Repetir cada: 5 minutos
 */

?>