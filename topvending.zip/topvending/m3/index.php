<?php
/**
 * Archivo: /topvending/m3/index.php
 * Propósito: Página principal del módulo de Suministros
 * Funcionalidad: Dashboard con resumen del estado de máquinas
 */

// SECCIÓN 1: Includes y verificación de sesión
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/log.php';
require_once __DIR__ . '/../clases/menu.php';
require_once __DIR__ . '/clases/Maquina.php';

// Verifica que el usuario esté logueado
requiereSesion();

// Verifica timeout de sesión (30 minutos)
verificarTimeout(30);

// Verifica que tenga el rol correcto
if (!verificarRol(['ADMIN', 'SUMINISTROS'])) {
    die('Acceso denegado. Este módulo es solo para personal de Suministros.');
}

// SECCIÓN 2: Obtención de datos
// Obtiene todas las máquinas
$maquinas = Maquina::obtenerTodas();

// Estadísticas generales
$totalMaquinas = count($maquinas);
$enServicio = 0;
$conIncidencias = 0;
$averiadas = 0;

foreach ($maquinas as $maquina) {
    if ($maquina->estaEnServicio()) {
        $enServicio++;
    }
    if ($maquina->tieneIncidencias()) {
        $conIncidencias++;
    }
    if ($maquina->getEstado() === 'Averiada') {
        $averiadas++;
    }
}

// Obtiene incidencias pendientes
$sqlIncidencias = "SELECT COUNT(*) as total FROM incidencias 
                   WHERE estado != 'Solucionada'";
$resultadoInc = ejecutarConsulta($sqlIncidencias);
$incidenciasPendientes = 0;
if ($resultadoInc) {
    $filaInc = $resultadoInc->fetch_assoc();
    $incidenciasPendientes = $filaInc['total'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Suministros</title>
    <link rel="stylesheet" href="/topvending/css/estilos.css">
    <style>
        /* Estilos para el dashboard */
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .page-header h1 {
            margin: 0 0 10px 0;
            color: #333;
        }
        
        .page-header p {
            margin: 0;
            color: #666;
        }
        
        /* Tarjetas de estadísticas */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        
        .stat-card.success {
            border-left-color: #10b981;
        }
        
        .stat-card.warning {
            border-left-color: #f59e0b;
        }
        
        .stat-card.danger {
            border-left-color: #ef4444;
        }
        
        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
        }
        
        .stat-card .value {
            font-size: 36px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }
        
        /* Botones de acción */
        .actions {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .btn-secondary:hover {
            background: #667eea;
            color: white;
        }
        
        /* Tabla de máquinas */
        .table-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-header h2 {
            margin: 0;
            color: #333;
            font-size: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background-color: #f9fafb;
        }
        
        th {
            padding: 15px 20px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        td {
            padding: 15px 20px;
            border-top: 1px solid #e5e7eb;
            color: #333;
        }
        
        tbody tr:hover {
            background-color: #f9fafb;
        }
        
        /* Badges de estado */
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .badge-warning {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .badge-danger {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        .badge-info {
            background-color: #dbeafe;
            color: #1e40af;
        }
        
        /* Botones de acción en tabla */
        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📊 Dashboard de Suministros</h1>
            <p>Monitorización y gestión del estado de máquinas de vending</p>
        </div>
        
        <!-- Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Máquinas</h3>
                <p class="value"><?php echo $totalMaquinas; ?></p>
            </div>
            
            <div class="stat-card success">
                <h3>En Servicio</h3>
                <p class="value"><?php echo $enServicio; ?></p>
            </div>
            
            <div class="stat-card warning">
                <h3>Con Incidencias</h3>
                <p class="value"><?php echo $conIncidencias; ?></p>
            </div>
            
            <div class="stat-card danger">
                <h3>Averiadas</h3>
                <p class="value"><?php echo $averiadas; ?></p>
            </div>
        </div>
        
        <!-- Botones de acción -->
        <div class="actions">
            <a href="monitorizar.php" class="btn btn-primary">
                🖥️ Monitorizar Máquinas
            </a>
            <a href="incidencias.php" class="btn btn-secondary">
                ⚠️ Incidencias (<?php echo $incidenciasPendientes; ?>)
            </a>
            <a href="reportes.php" class="btn btn-secondary">
                📈 Reportes
            </a>
        </div>
        
        <!-- Listado de máquinas -->
        <div class="table-container">
            <div class="table-header">
                <h2>Máquinas Registradas</h2>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Número Serie</th>
                        <th>Modelo</th>
                        <th>Cliente</th>
                        <th>Ubicación</th>
                        <th>Estado</th>
                        <th>Incidencias</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($maquinas as $maquina): ?>
                    <tr>
                        <td><?php echo $maquina->getIdMaquina(); ?></td>
                        <td><strong><?php echo htmlspecialchars($maquina->getNumSerie()); ?></strong></td>
                        <td>
                            <span class="badge badge-info">
                                <?php echo htmlspecialchars($maquina->getModelo()); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($maquina->getCliente()); ?></td>
                        <td><?php echo htmlspecialchars($maquina->getDireccion()); ?></td>
                        <td>
                            <?php 
                            $estado = $maquina->getEstado();
                            $badgeClass = 'badge-info';
                            if ($estado === 'En Servicio') $badgeClass = 'badge-success';
                            if ($estado === 'Averiada') $badgeClass = 'badge-danger';
                            if ($estado === 'Desactivada') $badgeClass = 'badge-warning';
                            ?>
                            <span class="badge <?php echo $badgeClass; ?>">
                                <?php echo htmlspecialchars($estado); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($maquina->tieneIncidencias()): ?>
                                <span class="badge badge-danger">Sí</span>
                            <?php else: ?>
                                <span class="badge badge-success">No</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="monitorizar.php?id=<?php echo $maquina->getIdMaquina(); ?>" 
                               class="btn btn-primary btn-small">
                                Ver Detalles
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($maquinas)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: #999;">
                            No hay máquinas registradas en el sistema
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>