<?php
/**
 * Archivo: /topvending/m3/clases/Maquina.php
 * Propósito: Clase para gestionar las máquinas de vending
 * Uso: Encapsula toda la lógica relacionada con máquinas
 */

require_once __DIR__ . '/../../clases/basedatos.php';
require_once __DIR__ . '/../../clases/log.php';

class Maquina {
    // Atributos privados de la clase
    private $idmaquina;
    private $numserie;
    private $idestado;
    private $idubicacion;
    private $capacidad;
    private $stockmax;
    private $modelo;
    private $foto;
    
    // Atributos adicionales para relaciones
    private $cliente;
    private $direccion;
    private $estadoDescripcion;
    private $productos;
    
    /**
     * Constructor: Inicializa la máquina
     * 
     * Parámetros: Array asociativo con los datos de la máquina
     * 
     * Ejemplo de uso:
     *   $maq = new Maquina([
     *       'idmaquina' => 1,
     *       'numserie' => 'SN12345678',
     *       'modelo' => 'STAR30',
     *       ...
     *   ]);
     */
    public function __construct($datos = []) {
        // Inicializa atributos con valores del array o null
        $this->idmaquina = $datos['idmaquina'] ?? null;
        $this->numserie = $datos['numserie'] ?? '';
        $this->idestado = $datos['idestado'] ?? 2;
        $this->idubicacion = $datos['idubicacion'] ?? null;
        $this->capacidad = $datos['capacidad'] ?? 30;
        $this->stockmax = $datos['stockmax'] ?? 20;
        $this->modelo = $datos['modelo'] ?? 'STAR30';
        $this->foto = $datos['foto'] ?? 'null';
        
        // Datos de relaciones
        $this->cliente = $datos['cliente'] ?? '';
        $this->direccion = $datos['dir'] ?? '';
        $this->estadoDescripcion = $datos['descripcion'] ?? '';
        $this->productos = [];
    }
    
    // ========== GETTERS ==========
    
    public function getIdMaquina() {
        return $this->idmaquina;
    }
    
    public function getNumSerie() {
        return $this->numserie;
    }
    
    public function getModelo() {
        return $this->modelo;
    }
    
    public function getCapacidad() {
        return $this->capacidad;
    }
    
    public function getStockMax() {
        return $this->stockmax;
    }
    
    public function getCliente() {
        return $this->cliente;
    }
    
    public function getDireccion() {
        return $this->direccion;
    }
    
    public function getEstado() {
        return $this->estadoDescripcion;
    }
    
    public function getProductos() {
        return $this->productos;
    }
    
    // ========== MÉTODOS ESTÁTICOS (no necesitan instancia) ==========
    
    /**
     * Método: obtenerTodas()
     * Propósito: Obtiene todas las máquinas de la BD
     * Retorna: Array de objetos Maquina
     * 
     * Este es un método estático, se llama así:
     *   $maquinas = Maquina::obtenerTodas();
     */
    public static function obtenerTodas() {
        // JOIN para obtener datos relacionados de estado y ubicación
        $sql = "SELECT m.*, e.descripcion, u.cliente, u.dir 
                FROM maquina m
                INNER JOIN estado e ON m.idestado = e.idestado
                INNER JOIN ubicacion u ON m.idubicacion = u.idubicacion
                ORDER BY m.idmaquina";
        
        $resultado = ejecutarConsulta($sql);
        $maquinas = [];
        
        // Convierte cada fila en un objeto Maquina
        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $maquinas[] = new Maquina($fila);
            }
        }
        
        return $maquinas;
    }
    
    /**
     * Método: obtenerPorId($id)
     * Propósito: Obtiene una máquina específica por su ID
     * Parámetros: $id - ID de la máquina
     * Retorna: Objeto Maquina o null si no existe
     */
    public static function obtenerPorId($id) {
        $sql = "SELECT m.*, e.descripcion, u.cliente, u.dir 
                FROM maquina m
                INNER JOIN estado e ON m.idestado = e.idestado
                INNER JOIN ubicacion u ON m.idubicacion = u.idubicacion
                WHERE m.idmaquina = ?";
        
        $resultado = ejecutarConsultaPreparada($sql, "i", [$id]);
        
        if ($resultado && $fila = $resultado->fetch_assoc()) {
            $maquina = new Maquina($fila);
            // Carga también los productos de la máquina
            $maquina->cargarProductos();
            return $maquina;
        }
        
        return null;
    }
    
    /**
     * Método: obtenerPorCliente($cliente)
     * Propósito: Obtiene máquinas filtradas por cliente
     * Parámetros: $cliente - Nombre del cliente
     * Retorna: Array de objetos Maquina
     */
    public static function obtenerPorCliente($cliente) {
        $sql = "SELECT m.*, e.descripcion, u.cliente, u.dir 
                FROM maquina m
                INNER JOIN estado e ON m.idestado = e.idestado
                INNER JOIN ubicacion u ON m.idubicacion = u.idubicacion
                WHERE u.cliente = ?
                ORDER BY m.idmaquina";
        
        $resultado = ejecutarConsultaPreparada($sql, "s", [$cliente]);
        $maquinas = [];
        
        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $maquinas[] = new Maquina($fila);
            }
        }
        
        return $maquinas;
    }
    
    /**
     * Método: obtenerPorModelo($modelo)
     * Propósito: Filtra máquinas por modelo
     * Parámetros: $modelo - STAR30, STAR24 o STAR42
     * Retorna: Array de objetos Maquina
     */
    public static function obtenerPorModelo($modelo) {
        $sql = "SELECT m.*, e.descripcion, u.cliente, u.dir 
                FROM maquina m
                INNER JOIN estado e ON m.idestado = e.idestado
                INNER JOIN ubicacion u ON m.idubicacion = u.idubicacion
                WHERE m.modelo = ?
                ORDER BY m.idmaquina";
        
        $resultado = ejecutarConsultaPreparada($sql, "s", [$modelo]);
        $maquinas = [];
        
        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $maquinas[] = new Maquina($fila);
            }
        }
        
        return $maquinas;
    }
    
    /**
     * Método: obtenerClientes()
     * Propósito: Obtiene lista única de clientes
     * Retorna: Array de nombres de clientes
     * Uso: Para llenar select/dropdown de filtros
     */
    public static function obtenerClientes() {
        $sql = "SELECT DISTINCT cliente FROM ubicacion ORDER BY cliente";
        $resultado = ejecutarConsulta($sql);
        $clientes = [];
        
        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $clientes[] = $fila['cliente'];
            }
        }
        
        return $clientes;
    }
    
    /**
     * Método: obtenerModelos()
     * Propósito: Obtiene lista de modelos disponibles
     * Retorna: Array de modelos
     */
    public static function obtenerModelos() {
        return ['STAR30', 'STAR24', 'STAR42'];
    }
    
    // ========== MÉTODOS DE INSTANCIA ==========
    
    /**
     * Método: cargarProductos()
     * Propósito: Carga los productos de esta máquina desde la BD
     * Llena el array $this->productos con los datos
     * 
     * Cada producto tiene: idproducto, marca, modelo, categoria, stock
     */
    public function cargarProductos() {
        $sql = "SELECT mp.*, p.marca, p.modelo, p.categoria 
                FROM maquinaproducto mp
                INNER JOIN producto p ON mp.idproducto = p.idproducto
                WHERE mp.idmaquina = ?
                ORDER BY mp.id";
        
        $resultado = ejecutarConsultaPreparada($sql, "i", [$this->idmaquina]);
        $this->productos = [];
        
        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $this->productos[] = $fila;
            }
        }
    }
    
    /**
     * Método: obtenerMatriz()
     * Propósito: Genera la matriz de productos según el modelo de máquina
     * Retorna: Array bidimensional [fila][columna] con datos del producto
     * 
     * Estructura según modelo:
     *   STAR30: 5 filas x 6 columnas = 30 posiciones
     *   STAR24: 4 filas x 6 columnas = 24 posiciones
     *   STAR42: 7 filas x 6 columnas = 42 posiciones
     * 
     * Cada celda contiene:
     *   ['posicion' => 1, 'marca' => 'COCACOLA', 'modelo' => 'Coke', 
     *    'stock' => 15, 'stockmax' => 20, 'porcentaje' => 75]
     */
    public function obtenerMatriz() {
        // Asegura que los productos estén cargados
        if (empty($this->productos)) {
            $this->cargarProductos();
        }
        
        // Determina dimensiones según modelo
        $dimensiones = $this->obtenerDimensiones();
        $filas = $dimensiones['filas'];
        $columnas = $dimensiones['columnas'];
        
        // Inicializa matriz vacía
        $matriz = [];
        $posicion = 0;
        
        for ($f = 0; $f < $filas; $f++) {
            $matriz[$f] = [];
            for ($c = 0; $c < $columnas; $c++) {
                // Si hay producto en esta posición, lo añade
                if (isset($this->productos[$posicion])) {
                    $prod = $this->productos[$posicion];
                    
                    // Calcula porcentaje de stock
                    $porcentaje = ($prod['stock'] / $this->stockmax) * 100;
                    
                    $matriz[$f][$c] = [
                        'posicion' => $posicion + 1,
                        'idproducto' => $prod['idproducto'],
                        'marca' => $prod['marca'],
                        'modelo' => $prod['modelo'],
                        'categoria' => $prod['categoria'],
                        'stock' => $prod['stock'],
                        'stockmax' => $this->stockmax,
                        'porcentaje' => round($porcentaje, 2)
                    ];
                } else {
                    // Celda vacía
                    $matriz[$f][$c] = [
                        'posicion' => $posicion + 1,
                        'vacia' => true
                    ];
                }
                $posicion++;
            }
        }
        
        return $matriz;
    }
    
    /**
     * Método: obtenerDimensiones()
     * Propósito: Retorna filas y columnas según el modelo
     * Retorna: Array ['filas' => X, 'columnas' => Y]
     */
    public function obtenerDimensiones() {
        switch ($this->modelo) {
            case 'STAR30':
                return ['filas' => 5, 'columnas' => 6];
            case 'STAR24':
                return ['filas' => 4, 'columnas' => 6];
            case 'STAR42':
                return ['filas' => 7, 'columnas' => 6];
            default:
                return ['filas' => 5, 'columnas' => 6];
        }
    }
    
    /**
     * Método: tieneIncidencias()
     * Propósito: Verifica si la máquina tiene incidencias no resueltas
     * Retorna: true si tiene incidencias, false si no
     */
    public function tieneIncidencias() {
        $sql = "SELECT COUNT(*) as total 
                FROM incidencias 
                WHERE idmaquina = ? 
                AND estado != 'Solucionada'";
        
        $resultado = ejecutarConsultaPreparada($sql, "i", [$this->idmaquina]);
        
        if ($resultado && $fila = $resultado->fetch_assoc()) {
            return $fila['total'] > 0;
        }
        
        return false;
    }
    
    /**
     * Método: estaEnServicio()
     * Propósito: Verifica si la máquina está en servicio (estado 2)
     * Retorna: true si está en servicio, false si no
     */
    public function estaEnServicio() {
        return $this->idestado == 2;
    }
    
    /**
     * Método: actualizarStock($idproducto, $cantidad)
     * Propósito: Actualiza el stock de un producto en la máquina
     * Parámetros:
     *   $idproducto - ID del producto a actualizar
     *   $cantidad - Nueva cantidad (puede ser negativa para restar)
     * Retorna: true si se actualizó, false si hubo error
     * 
     * Uso: Para simular consumos o reposiciones
     */
    public function actualizarStock($idproducto, $cantidad) {
        // Si cantidad es negativa, resta; si es positiva, suma
        $operador = $cantidad >= 0 ? '+' : '';
        
        $sql = "UPDATE maquinaproducto 
                SET stock = stock $operador ? 
                WHERE idmaquina = ? AND idproducto = ?";
        
        $conn = conectarBD();
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $cantidad, $this->idmaquina, $idproducto);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        if ($resultado) {
            // Registra en log
            $tipo = $cantidad >= 0 ? 'Reposición' : 'Consumo';
            registrarLog('INFO', null, 'SISTEMA', $this->idmaquina, null, 
                        $idproducto, abs($cantidad), 
                        "$tipo de producto en máquina {$this->numserie}");
        }
        
        return $resultado;
    }
    
    /**
     * Método: reponer($idproducto, $cantidad)
     * Propósito: Repone stock de un producto hasta el máximo
     * Parámetros:
     *   $idproducto - ID del producto (null = todos los productos)
     *   $cantidad - Cantidad a reponer (null = hasta stockmax)
     */
    public function reponer($idproducto = null, $cantidad = null) {
        if ($idproducto === null) {
            // Repone todos los productos al máximo
            $sql = "UPDATE maquinaproducto 
                    SET stock = ? 
                    WHERE idmaquina = ?";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $this->stockmax, $this->idmaquina);
            $resultado = $stmt->execute();
            $stmt->close();
            
            if ($resultado) {
                registrarLog('INFO', null, 'SISTEMA', $this->idmaquina, null, 
                            null, null, "Reposición completa de máquina {$this->numserie}");
            }
            
            return $resultado;
        } else {
            // Repone un producto específico
            $cantidadFinal = $cantidad ?? $this->stockmax;
            
            $sql = "UPDATE maquinaproducto 
                    SET stock = ? 
                    WHERE idmaquina = ? AND idproducto = ?";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iii", $cantidadFinal, $this->idmaquina, $idproducto);
            $resultado = $stmt->execute();
            $stmt->close();
            
            return $resultado;
        }
    }
    
    /**
     * Método: toArray()
     * Propósito: Convierte el objeto a array (útil para JSON)
     * Retorna: Array asociativo con todos los datos
     */
    public function toArray() {
        return [
            'idmaquina' => $this->idmaquina,
            'numserie' => $this->numserie,
            'idestado' => $this->idestado,
            'estado' => $this->estadoDescripcion,
            'modelo' => $this->modelo,
            'capacidad' => $this->capacidad,
            'stockmax' => $this->stockmax,
            'cliente' => $this->cliente,
            'direccion' => $this->direccion,
            'enServicio' => $this->estaEnServicio(),
            'tieneIncidencias' => $this->tieneIncidencias(),
            'productos' => $this->productos
        ];
    }
}
?>