<?php
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/menu.php';

requiereSesion();
verificarTimeout(30);

if (!verificarRol(['ADMIN'])) {
    die('Acceso denegado. Este módulo es solo para administradores.');
}

// Obtiene estadísticas
$sqlMaquinas = "SELECT COUNT(*) as total FROM maquina";
$sqlProductos = "SELECT COUNT(*) as total FROM producto";
$sqlLogs = "SELECT COUNT(*) as total FROM log";

$totalMaquinas = ejecutarConsulta($sqlMaquinas)->fetch_assoc()['total'];
$totalProductos = ejecutarConsulta($sqlProductos)->fetch_assoc()['total'];
$totalLogs = ejecutarConsulta($sqlLogs)->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Administración</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        
        .menu-principal {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .menu-titulo { margin: 0; }
        
        .menu-usuario {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .btn-logout {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            color: #666;
            margin-bottom: 15px;
            font-size: 14px;
            text-transform: uppercase;
        }
        
        .stat-card .value {
            font-size: 48px;
            font-weight: bold;
            color: #667eea;
        }
        
        .actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .action-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .action-card h3 {
            margin: 0 0 15px 0;
            color: #333;
        }
        
        .action-card p {
            color: #666;
            margin-bottom: 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <div class="page-header">
            <h1>⚙️ Panel de Administración</h1>
            <p>Gestión completa del sistema TopVending</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Máquinas</h3>
                <div class="value"><?php echo $totalMaquinas; ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Total Productos</h3>
                <div class="value"><?php echo $totalProductos; ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Registros de Log</h3>
                <div class="value"><?php echo $totalLogs; ?></div>
            </div>
        </div>
        
        <h2 style="margin-bottom: 20px;">🚀 Acciones Rápidas</h2>
        <div class="actions">
            <div class="action-card">
                <h3>🏭 Gestión de Máquinas</h3>
                <p>Administrar el parque de máquinas</p>
                <a href="maquinas.php" class="btn">Ir a Máquinas</a>
            </div>
            
            <div class="action-card">
                <h3>🍫 Gestión de Productos</h3>
                <p>Administrar catálogo de productos</p>
                <a href="productos.php" class="btn">Ir a Productos</a>
            </div>
            
            <div class="action-card">
                <h3>📋 Registro de Logs</h3>
                <p>Visualizar eventos del sistema</p>
                <a href="logs.php" class="btn">Ver Logs</a>
            </div>
        </div>
    </div>
</body>
</html>