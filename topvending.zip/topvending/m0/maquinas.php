<?php
/**
 * Archivo: /topvending/m0/maquinas.php
 * Propósito: CRUD completo de máquinas con paginación
 * Funcionalidad: Listar, Crear, Editar y Eliminar máquinas
 */

// ========== SECCIÓN 1: INCLUDES Y SEGURIDAD ==========
require_once __DIR__ . '/../clases/basedatos.php';
require_once __DIR__ . '/../clases/sesion.php';
require_once __DIR__ . '/../clases/log.php';
require_once __DIR__ . '/../clases/menu.php';
require_once __DIR__ . '/../clases/config.php';

// Verifica que el usuario esté logueado y tenga rol ADMIN
requiereSesion();
verificarTimeout(30);

if (!verificarRol(['ADMIN'])) {
    die('Acceso denegado. Este módulo es solo para administradores.');
}

// ========== SECCIÓN 2: PROCESAMIENTO DE ACCIONES ==========

$mensaje = '';
$tipoMensaje = '';

// Procesar acción de ELIMINAR
if (isset($_GET['accion']) && $_GET['accion'] === 'eliminar' && isset($_GET['id'])) {
    $idEliminar = (int)$_GET['id'];
    
    // Verifica que la máquina no esté en servicio antes de eliminar
    $sqlVerificar = "SELECT idestado, numserie FROM maquina WHERE idmaquina = ?";
    $resultadoVerif = ejecutarConsultaPreparada($sqlVerificar, "i", [$idEliminar]);
    
    if ($resultadoVerif && $fila = $resultadoVerif->fetch_assoc()) {
        // Estado 2 = En Servicio
        if ($fila['idestado'] == 2) {
            $mensaje = "No se puede eliminar la máquina {$fila['numserie']} porque está en servicio";
            $tipoMensaje = 'warning';
        } else {
            // Elimina primero los productos asociados
            $sqlEliminarProd = "DELETE FROM maquinaproducto WHERE idmaquina = ?";
            ejecutarConsultaPreparada($sqlEliminarProd, "i", [$idEliminar]);
            
            // Elimina la máquina
            $sqlEliminar = "DELETE FROM maquina WHERE idmaquina = ?";
            $resultado = ejecutarConsultaPreparada($sqlEliminar, "i", [$idEliminar]);
            
            if ($resultado) {
                $mensaje = "Máquina eliminada correctamente";
                $tipoMensaje = 'success';
                
                $datosSesion = obtenerDatosSesion();
                registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                           $idEliminar, null, null, null, 
                           "Máquina eliminada: {$fila['numserie']}");
            } else {
                $mensaje = "Error al eliminar la máquina";
                $tipoMensaje = 'danger';
            }
        }
    }
}

// Procesar acción de CREAR/EDITAR
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtiene los datos del formulario
    $idmaquina = isset($_POST['idmaquina']) ? (int)$_POST['idmaquina'] : null;
    $numserie = trim($_POST['numserie']);
    $idestado = (int)$_POST['idestado'];
    $idubicacion = (int)$_POST['idubicacion'];
    $capacidad = (int)$_POST['capacidad'];
    $stockmax = (int)$_POST['stockmax'];
    $modelo = trim($_POST['modelo']);
    $foto = trim($_POST['foto']);
    
    // Validación básica
    if (empty($numserie) || empty($modelo)) {
        $mensaje = "El número de serie y el modelo son obligatorios";
        $tipoMensaje = 'danger';
    } else {
        if ($idmaquina) {
            // ACTUALIZAR máquina existente
            $sql = "UPDATE maquina 
                    SET numserie = ?, idestado = ?, idubicacion = ?, 
                        capacidad = ?, stockmax = ?, modelo = ?, foto = ?
                    WHERE idmaquina = ?";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("siiisssi", $numserie, $idestado, $idubicacion, 
                            $capacidad, $stockmax, $modelo, $foto, $idmaquina);
            $resultado = $stmt->execute();
            $stmt->close();
            
            if ($resultado) {
                $mensaje = "Máquina actualizada correctamente";
                $tipoMensaje = 'success';
                
                $datosSesion = obtenerDatosSesion();
                registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                           $idmaquina, null, null, null, 
                           "Máquina actualizada: $numserie");
            } else {
                $mensaje = "Error al actualizar la máquina";
                $tipoMensaje = 'danger';
            }
        } else {
            // CREAR nueva máquina
            $sql = "INSERT INTO maquina (numserie, idestado, idubicacion, capacidad, 
                                        stockmax, modelo, foto) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            $conn = conectarBD();
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("siiisss", $numserie, $idestado, $idubicacion, 
                            $capacidad, $stockmax, $modelo, $foto);
            $resultado = $stmt->execute();
            $nuevoId = $conn->insert_id;
            $stmt->close();
            
            if ($resultado) {
                $mensaje = "Máquina creada correctamente";
                $tipoMensaje = 'success';
                
                $datosSesion = obtenerDatosSesion();
                registrarLog('INFO', $datosSesion['idempleado'], $datosSesion['rol'], 
                           $nuevoId, null, null, null, 
                           "Nueva máquina creada: $numserie");
            } else {
                $mensaje = "Error al crear la máquina";
                $tipoMensaje = 'danger';
            }
        }
    }
}

// ========== SECCIÓN 3: PAGINACIÓN ==========

// Obtiene el número de página actual (por defecto 1)
$paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($paginaActual < 1) $paginaActual = 1;

// Obtiene el total de registros
$sqlTotal = "SELECT COUNT(*) as total FROM maquina";
$resultadoTotal = ejecutarConsulta($sqlTotal);
$filaTotal = $resultadoTotal->fetch_assoc();
$totalRegistros = $filaTotal['total'];

// Calcula el número total de páginas
$registrosPorPagina = REGISTROS_POR_PAGINA;
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);

// Calcula el offset (desde qué registro empezar)
$offset = ($paginaActual - 1) * $registrosPorPagina;

// Obtiene los registros de la página actual
$sql = "SELECT m.*, e.descripcion as estado, u.cliente, u.dir 
        FROM maquina m
        INNER JOIN estado e ON m.idestado = e.idestado
        INNER JOIN ubicacion u ON m.idubicacion = u.idubicacion
        ORDER BY m.idmaquina DESC
        LIMIT ? OFFSET ?";

$conn = conectarBD();
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $registrosPorPagina, $offset);
$stmt->execute();
$resultado = $stmt->get_result();
$stmt->close();

// ========== SECCIÓN 4: DATOS PARA FORMULARIO ==========

// Obtiene estados disponibles
$sqlEstados = "SELECT * FROM estado ORDER BY idestado";
$estados = ejecutarConsulta($sqlEstados);

// Obtiene ubicaciones disponibles
$sqlUbicaciones = "SELECT * FROM ubicacion ORDER BY cliente";
$ubicaciones = ejecutarConsulta($sqlUbicaciones);

// Si estamos editando, obtiene los datos de la máquina
$maquinaEditar = null;
if (isset($_GET['accion']) && $_GET['accion'] === 'editar' && isset($_GET['id'])) {
    $idEditar = (int)$_GET['id'];
    $sqlEditar = "SELECT * FROM maquina WHERE idmaquina = ?";
    $resultadoEditar = ejecutarConsultaPreparada($sqlEditar, "i", [$idEditar]);
    if ($resultadoEditar) {
        $maquinaEditar = $resultadoEditar->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopVending - Gestión de Máquinas</title>
    <link rel="stylesheet" href="/topvending/css/estilos.css">
    <style>
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .page-header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .btn-nuevo { margin-bottom: 20px; }
        
        /* Estilos del formulario modal */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; 
                 background-color: rgba(0,0,0,0.5); overflow: auto; }
        .modal.show { display: block; }
        .modal-content { background-color: white; margin: 5% auto; padding: 30px; border-radius: 8px; 
                        width: 90%; max-width: 600px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-header h2 { margin: 0; color: #333; }
        .close { font-size: 28px; font-weight: bold; color: #999; cursor: pointer; }
        .close:hover { color: #333; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px; }
        .form-row.full { grid-template-columns: 1fr; }
        
        /* Paginación */
        .pagination { display: flex; justify-content: center; gap: 10px; margin-top: 30px; }
        .pagination a, .pagination span { padding: 8px 15px; background: white; border: 1px solid #ddd; 
                                         border-radius: 5px; text-decoration: none; color: #333; }
        .pagination a:hover { background: #667eea; color: white; border-color: #667eea; }
        .pagination .active { background: #667eea; color: white; border-color: #667eea; font-weight: bold; }
        
        /* Tabla responsive */
        .table-container { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden; }
        .info-paginacion { padding: 15px 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; 
                          color: #666; font-size: 14px; }
        
        /* Botones de acción en tabla */
        .btn-actions { display: flex; gap: 5px; }
        .btn-icon { padding: 6px 10px; font-size: 12px; }
    </style>
</head>
<body>
    <?php mostrarMenu(); ?>
    
    <div class="container">
        <div class="page-header">
            <h1>🏭 Gestión de Máquinas</h1>
            <p>Administración completa del parque de máquinas de vending</p>
        </div>
        
        <?php if ($mensaje): ?>
        <div class="alert alert-<?php echo $tipoMensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
        <?php endif; ?>
        
        <button onclick="mostrarModal()" class="btn btn-primary btn-nuevo">
            ➕ Nueva Máquina
        </button>
        
        <!-- Tabla de máquinas -->
        <div class="table-container">
            <div class="info-paginacion">
                Mostrando <?php echo $offset + 1; ?> - <?php echo min($offset + $registrosPorPagina, $totalRegistros); ?> 
                de <?php echo $totalRegistros; ?> máquinas
                | Página <?php echo $paginaActual; ?> de <?php echo $totalPaginas; ?>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Número Serie</th>
                        <th>Modelo</th>
                        <th>Estado</th>
                        <th>Cliente</th>
                        <th>Ubicación</th>
                        <th>Capacidad</th>
                        <th>Stock Max</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($maquina = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $maquina['idmaquina']; ?></td>
                        <td><strong><?php echo htmlspecialchars($maquina['numserie']); ?></strong></td>
                        <td><span class="badge badge-info"><?php echo htmlspecialchars($maquina['modelo']); ?></span></td>
                        <td>
                            <?php 
                            $badgeClass = 'badge-info';
                            if ($maquina['estado'] === 'En Servicio') $badgeClass = 'badge-success';
                            if ($maquina['estado'] === 'Averiada') $badgeClass = 'badge-danger';
                            if ($maquina['estado'] === 'Desactivada') $badgeClass = 'badge-warning';
                            ?>
                            <span class="badge <?php echo $badgeClass; ?>">
                                <?php echo htmlspecialchars($maquina['estado']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($maquina['cliente']); ?></td>
                        <td><?php echo htmlspecialchars($maquina['dir']); ?></td>
                        <td><?php echo $maquina['capacidad']; ?></td>
                        <td><?php echo $maquina['stockmax']; ?></td>
                        <td>
                            <div class="btn-actions">
                                <a href="?accion=editar&id=<?php echo $maquina['idmaquina']; ?>&pagina=<?php echo $paginaActual; ?>" 
                                   class="btn btn-secondary btn-icon">✏️ Editar</a>
                                <a href="?accion=eliminar&id=<?php echo $maquina['idmaquina']; ?>&pagina=<?php echo $paginaActual; ?>" 
                                   class="btn btn-danger btn-icon"
                                   onclick="return confirm('¿Está seguro de eliminar esta máquina?')">🗑️ Eliminar</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php if ($totalRegistros == 0): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px; color: #999;">
                            No hay máquinas registradas
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <!-- Paginación -->
            <?php if ($totalPaginas > 1): ?>
            <div class="pagination">
                <?php if ($paginaActual > 1): ?>
                    <a href="?pagina=<?php echo $paginaActual - 1; ?>">← Anterior</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                    <?php if ($i == $paginaActual): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($paginaActual < $totalPaginas): ?>
                    <a href="?pagina=<?php echo $paginaActual + 1; ?>">Siguiente →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal de formulario -->
    <div id="modalForm" class="modal <?php echo ($maquinaEditar ? 'show' : ''); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h2><?php echo $maquinaEditar ? 'Editar Máquina' : 'Nueva Máquina'; ?></h2>
                <span class="close" onclick="cerrarModal()">&times;</span>
            </div>
            
            <form method="POST" action="?pagina=<?php echo $paginaActual; ?>">
                <?php if ($maquinaEditar): ?>
                <input type="hidden" name="idmaquina" value="<?php echo $maquinaEditar['idmaquina']; ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Número de Serie *</label>
                        <input type="text" name="numserie" class="form-control" required
                               value="<?php echo $maquinaEditar ? htmlspecialchars($maquinaEditar['numserie']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Modelo *</label>
                        <select name="modelo" class="form-control" required>
                            <?php foreach (MODELOS_MAQUINA as $modelo): ?>
                            <option value="<?php echo $modelo; ?>" 
                                    <?php echo ($maquinaEditar && $maquinaEditar['modelo'] === $modelo) ? 'selected' : ''; ?>>
                                <?php echo $modelo; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Estado *</label>
                        <select name="idestado" class="form-control" required>
                            <?php 
                            $estados->data_seek(0); // Resetea el puntero del resultado
                            while ($estado = $estados->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $estado['idestado']; ?>"
                                    <?php echo ($maquinaEditar && $maquinaEditar['idestado'] == $estado['idestado']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($estado['descripcion']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Ubicación *</label>
                        <select name="idubicacion" class="form-control" required>
                            <?php 
                            $ubicaciones->data_seek(0);
                            while ($ubicacion = $ubicaciones->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $ubicacion['idubicacion']; ?>"
                                    <?php echo ($maquinaEditar && $maquinaEditar['idubicacion'] == $ubicacion['idubicacion']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($ubicacion['cliente'] . ' - ' . $ubicacion['dir']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Capacidad *</label>
                        <input type="number" name="capacidad" class="form-control" required min="1"
                               value="<?php echo $maquinaEditar ? $maquinaEditar['capacidad'] : '30'; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Stock Máximo *</label>
                        <input type="number" name="stockmax" class="form-control" required min="1"
                               value="<?php echo $maquinaEditar ? $maquinaEditar['stockmax'] : '20'; ?>">
                    </div>
                </div>
                
                <div class="form-row full">
                    <div class="form-group">
                        <label>Foto (URL)</label>
                        <input type="text" name="foto" class="form-control"
                               value="<?php echo $maquinaEditar ? htmlspecialchars($maquinaEditar['foto']) : 'null'; ?>">
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" onclick="cerrarModal()" class="btn btn-secondary">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <?php echo $maquinaEditar ? 'Actualizar' : 'Crear'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Funciones para el modal
        function mostrarModal() {
            document.getElementById('modalForm').classList.add('show');
        }
        
        function cerrarModal() {
            // Redirige a la página sin parámetros de edición
            window.location.href = '?pagina=<?php echo $paginaActual; ?>';
        }
        
        // Cierra el modal al hacer clic fuera de él
        window.onclick = function(event) {
            const modal = document.getElementById('modalForm');
            if (event.target == modal) {
                cerrarModal();
            }
        }
    </script>
</body>
</html>