<?php
/**
 * Archivo: /topvending/index.php
 * CORREGIDO: Sin bucles de redirección
 */

// Ruta ABSOLUTA con barra inicial
header("Location: /topvending/login.php");
exit();
?>